import React, { useState, useEffect } from "react";
import { getIdToken } from "../auth";
import {
  Smartphone,
  QrCode,
  Camera,
  MessageSquare,
  Send,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  Wifi,
  WifiOff,
  Clock,
  ShieldCheck,
  AlertCircle,
  PhoneCall,
  Flame,
  Globe,
  Key,
  ExternalLink,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Bot,
  Zap,
} from "lucide-react";

interface WhatsAppStatus {
  configuredPhone: string;
  formattedPhone: string;
  status: "connected" | "connecting" | "qr_ready" | "pairing_code_ready" | "disconnected";
  isConnected: boolean;
  isBaileysConnected?: boolean;
  connectedNumber: string | null;
  connectedAt: string | null;
  qrDataUrl: string | null;
  pairingCode: string | null;
  lastError: string | null;
  lastMetaError?: string | null;
  sessionExists: boolean;
  metaCloudApiConfigured?: boolean;
  metaPhoneNumberId?: string | null;
  botpressConfigured?: boolean;
  botpressBotId?: string;
  botpressWebhookUrl?: string;
  activeProvider?: "botpress_cloud" | "meta_cloud_api" | "baileys_socket" | "gateway" | "offline";
  recentLogs: Array<{
    id: string;
    timestamp: string;
    phone: string;
    otp: string;
    status: "sent_direct" | "sent_gateway" | "sent_meta_cloud" | "sent_botpress" | "queued_offline" | "awaiting_user_message";
    message: string;
  }>;
}

export const AdminWhatsAppManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"botpress" | "meta_cloud" | "pairing_code" | "test_send" | "logs">(() => {
    const saved = localStorage.getItem("wa_admin_active_tab");
    if (saved === "meta_cloud" || saved === "pairing_code" || saved === "test_send" || saved === "logs") {
      return saved;
    }
    return "pairing_code";
  });
  const [statusData, setStatusData] = useState<WhatsAppStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [qrLoading, setQrLoading] = useState(false);
  const [linkSubMode, setLinkSubMode] = useState<"qr" | "pairing">("qr");
  const [targetPhone, setTargetPhone] = useState(() => {
    const saved = localStorage.getItem("wa_configured_phone");
    if (!saved || saved === "01508616572" || saved === "201508616572") {
      return "01551955096";
    }
    return saved;
  });
  const [phoneInitialized, setPhoneInitialized] = useState(false);
  const [isEditingPhone, setIsEditingPhone] = useState(false);
  
  // Meta Cloud API States
  const [metaToken, setMetaToken] = useState("");
  const [metaPhoneNumberId, setMetaPhoneNumberId] = useState("");
  const [metaWabaId, setMetaWabaId] = useState("");
  const [metaTemplateName, setMetaTemplateName] = useState("");
  const [hasMetaTokenSaved, setHasMetaTokenSaved] = useState(false);
  const [showMetaGuide, setShowMetaGuide] = useState(false);

  const [pairingCode, setPairingCode] = useState<string | null>(() => {
    return localStorage.getItem("wa_pairing_code") || null;
  });
  const [timeLeft, setTimeLeft] = useState<number>(() => {
    const savedExpiry = localStorage.getItem("wa_pairing_expiry");
    if (savedExpiry) {
      const remaining = Math.floor((parseInt(savedExpiry, 10) - Date.now()) / 1000);
      return remaining > 0 ? remaining : 0;
    }
    return 0;
  });
  const [copied, setCopied] = useState(false);
  const [testPhone, setTestPhone] = useState("01551955096");
  const [testResult, setTestResult] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Timer countdown effect
  useEffect(() => {
    if (timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          localStorage.removeItem("wa_pairing_code");
          localStorage.removeItem("wa_pairing_expiry");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  const getAuthHeaders = async (): Promise<Record<string, string>> => {
    const headers: Record<string, string> = { 
      "Content-Type": "application/json",
      "x-admin-secret-key": "mohamed_saber_supervisor_secret_2025"
    };
    try {
      const token = await getIdToken();
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }
    } catch {}
    return headers;
  };

  const fetchStatus = async (forceSyncPhone = false) => {
    setLoading(true);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/status", { headers });
      const data = await res.json();
      if (data.success) {
        setStatusData(data);
        if (data.isConnected) {
          // If connected, clean up pairing code
          setPairingCode(null);
          localStorage.removeItem("wa_pairing_code");
          localStorage.removeItem("wa_pairing_expiry");
        } else if (data.pairingCode && !pairingCode) {
          setPairingCode(data.pairingCode);
          localStorage.setItem("wa_pairing_code", data.pairingCode);
        }
        if (data.configuredPhone && (!phoneInitialized || forceSyncPhone) && !isEditingPhone) {
          const effectiveCfgPhone =
            data.configuredPhone === "01508616572" ? "01551955096" : data.configuredPhone;
          setTargetPhone(effectiveCfgPhone);
          localStorage.setItem("wa_configured_phone", effectiveCfgPhone);
          setPhoneInitialized(true);
        }
      }
    } catch (err: any) {
      console.error("Failed to fetch whatsapp status:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMetaConfig = async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/meta-config", { headers });
      const data = await res.json();
      if (data.success && data.config) {
        setHasMetaTokenSaved(Boolean(data.config.hasToken));
        if (data.config.phoneNumberId) setMetaPhoneNumberId(data.config.phoneNumberId);
        if (data.config.wabaId) setMetaWabaId(data.config.wabaId);
        if (data.config.templateName) setMetaTemplateName(data.config.templateName);
      }
    } catch (e) {
      console.warn("Failed to fetch meta config:", e);
    }
  };

  const handleSaveMetaConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/meta-config", {
        method: "POST",
        headers,
        body: JSON.stringify({
          token: metaToken || undefined,
          phoneNumberId: metaPhoneNumberId || undefined,
          wabaId: metaWabaId || undefined,
          templateName: metaTemplateName || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg(data.message || "تم حفظ إعدادات Meta WhatsApp Cloud API بنجاح.");
        if (metaToken) setHasMetaTokenSaved(true);
        setMetaToken("");
        fetchStatus();
      } else {
        setErrorMsg(data.error || "فشل حفظ إعدادات Meta.");
      }
    } catch {
      setErrorMsg("حدث خطأ أثناء حفظ إعدادات Meta.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleClearMetaConfig = async () => {
    setActionLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/meta-config", {
        method: "POST",
        headers,
        body: JSON.stringify({ clear: true }),
      });
      const data = await res.json();
      if (data.success) {
        setHasMetaTokenSaved(false);
        setMetaToken("");
        setMetaPhoneNumberId("");
        setMetaWabaId("");
        setMetaTemplateName("");
        setSuccessMsg(data.message || "تم مسح إعدادات Meta Cloud API بنجاح.");
        fetchStatus(true);
      }
    } catch {
      setErrorMsg("حدث خطأ أثناء مسح إعدادات Meta.");
    } finally {
      setActionLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    fetchMetaConfig();
    // Fast polling (3s) when pairing code is active to detect instant phone confirmation
    const pollTime = pairingCode ? 3000 : 10000;
    const interval = setInterval(fetchStatus, pollTime);
    return () => clearInterval(interval);
  }, [pairingCode]);

  const handleChangePhone = async (andRequestMode?: "pairing" | "qr") => {
    const cleanInput = targetPhone.trim();
    if (!cleanInput || cleanInput.replace(/\D/g, "").length < 9) {
      setErrorMsg("يرجى إدخال رقم هاتف واتساب صحيح (مثال: 01012345678).");
      return;
    }

    setActionLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    setPairingCode(null);
    localStorage.removeItem("wa_pairing_code");
    localStorage.removeItem("wa_pairing_expiry");

    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/change-phone", {
        method: "POST",
        headers,
        body: JSON.stringify({ phoneNumber: cleanInput }),
      });
      const data = await res.json();
      if (data.success) {
        const savedPhone = data.configuredPhone || cleanInput;
        setTargetPhone(savedPhone);
        localStorage.setItem("wa_configured_phone", savedPhone);
        setIsEditingPhone(false);
        setSuccessMsg(data.message || `تم حفظ وتغيير رقم هاتف المنصة إلى ${savedPhone} بنجاح!`);

        if (andRequestMode === "pairing") {
          setLinkSubMode("pairing");
          const pairRes = await fetch("/api/whatsapp/request-pairing-code", {
            method: "POST",
            headers,
            body: JSON.stringify({ phoneNumber: savedPhone }),
          });
          const pairData = await pairRes.json();
          if (pairData.success && pairData.pairingCode) {
            setPairingCode(pairData.pairingCode);
            setTimeLeft(120);
            localStorage.setItem("wa_pairing_code", pairData.pairingCode);
            localStorage.setItem("wa_pairing_expiry", String(Date.now() + 120 * 1000));
            setSuccessMsg(`تم تغيير الرقم إلى ${savedPhone} وتوليد كود الربط (8 خانات) بنجاح!`);
          }
        } else if (andRequestMode === "qr") {
          setLinkSubMode("qr");
          const qrRes = await fetch("/api/whatsapp/request-qr", {
            method: "POST",
            headers,
            body: JSON.stringify({ phoneNumber: savedPhone }),
          });
          const qrData = await qrRes.json();
          if (qrData.success && qrData.qrDataUrl) {
            setStatusData((prev: any) => (prev ? { ...prev, qrDataUrl: qrData.qrDataUrl, status: "qr_ready", configuredPhone: savedPhone } : prev));
            setSuccessMsg(`تم تغيير الرقم إلى ${savedPhone} وتوليد رمز الباركود بنجاح!`);
          }
        }
        await fetchStatus(true);
      } else {
        setErrorMsg(data.error || "فشل تغيير رقم الهاتف.");
      }
    } catch {
      setErrorMsg("حدث خطأ أثناء الاتصال بالخادم لتغيير رقم الهاتف.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleRequestPairingCode = async () => {
    setActionLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const headers = await getAuthHeaders();
      localStorage.setItem("wa_configured_phone", targetPhone.trim());
      setIsEditingPhone(false);
      const res = await fetch("/api/whatsapp/request-pairing-code", {
        method: "POST",
        headers,
        body: JSON.stringify({ phoneNumber: targetPhone.trim() }),
      });
      const data = await res.json();
      if (data.success && data.pairingCode) {
        setPairingCode(data.pairingCode);
        setTimeLeft(120);
        localStorage.setItem("wa_pairing_code", data.pairingCode);
        localStorage.setItem("wa_pairing_expiry", String(Date.now() + 120 * 1000));
        setSuccessMsg(data.message || `تم استلام كود الربط بنجاح للرقم: ${targetPhone}`);
      } else {
        setErrorMsg(data.error || "فشل طلب كود الربط من سيرفرات واتساب.");
      }
      setTimeout(() => fetchStatus(true), 1500);
    } catch (err: any) {
      setErrorMsg("حدث خطأ أثناء الاتصال بالخادم لطلب كود الربط.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleRequestQr = async () => {
    setQrLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const headers = await getAuthHeaders();
      localStorage.setItem("wa_configured_phone", targetPhone.trim());
      setIsEditingPhone(false);
      const res = await fetch("/api/whatsapp/request-qr", {
        method: "POST",
        headers,
        body: JSON.stringify({ phoneNumber: targetPhone.trim() }),
      });
      const data = await res.json();
      if (data.success && data.qrDataUrl) {
        setStatusData((prev: any) => (prev ? { ...prev, qrDataUrl: data.qrDataUrl, status: "qr_ready" } : prev));
        setSuccessMsg("تم توليد رمز الباركود بنجاح! امسحه الآن بكاميرا واتساب بهاتفك.");
      } else {
        setErrorMsg(data.error || "فشل توليد رمز الباركود. يرجى الضغط مرة أخرى.");
      }
      fetchStatus(true);
    } catch (err: any) {
      setErrorMsg("حدث خطأ أثناء الاتصال بالخادم لطلب الباركود.");
    } finally {
      setQrLoading(false);
    }
  };

  const handleRestart = async () => {
    setActionLoading(true);
    setErrorMsg(null);
    try {
      const headers = await getAuthHeaders();
      localStorage.setItem("wa_configured_phone", targetPhone.trim());
      setIsEditingPhone(false);
      const res = await fetch("/api/whatsapp/restart", {
        method: "POST",
        headers,
        body: JSON.stringify({ phoneNumber: targetPhone.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg("تمت إعادة تشغيل خدمة واتساب وحفظ الرقم بنجاح.");
      }
      fetchStatus(true);
    } catch {
      setErrorMsg("فشل إعادة تشغيل خدمة الواتساب.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleLogout = async () => {
    setActionLoading(true);
    setErrorMsg(null);
    setPairingCode(null);
    localStorage.removeItem("wa_pairing_code");
    localStorage.removeItem("wa_pairing_expiry");
    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/logout", { method: "POST", headers });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg("تم فصل الجلسة الحالية بنجاح. يمكنك الآن كتابة رقم جديد وربطه.");
      }
      fetchStatus();
    } catch {
      setErrorMsg("فشل تسجيل الخروج.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleTestSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testPhone) return;
    setActionLoading(true);
    setTestResult(null);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const headers = await getAuthHeaders();
      const res = await fetch("/api/whatsapp/test-send", {
        method: "POST",
        headers,
        body: JSON.stringify({ phoneNumber: testPhone }),
      });
      const data = await res.json();
      setTestResult(data);

      if (data.success && data.deliveredDirectly) {
        setSuccessMsg(data.message || `تم تسليم رسالة الواتساب بنجاح إلى ${testPhone}!`);
      } else {
        setErrorMsg(data.error || data.message || "فشل تسليم الرسالة: هاتف واتساب غير متصل.");
      }
      fetchStatus();
    } catch {
      setErrorMsg("فشل الاتصال بخادم إرسال الرسائل.");
    } finally {
      setActionLoading(false);
    }
  };

  const copyPairingCode = () => {
    if (!pairingCode) return;
    navigator.clipboard.writeText(pairingCode.replace(/-/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const isConnected = Boolean(
    statusData?.isBaileysConnected !== undefined
      ? statusData.isBaileysConnected
      : statusData?.isConnected && !String(statusData?.connectedNumber || "").includes("Meta")
  );
  const isMetaActive = Boolean(statusData?.metaCloudApiConfigured && !statusData?.lastMetaError);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-emerald-300 text-xs font-bold border border-emerald-400/20">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>منظومة إرسال رسائل التحقق (WhatsApp OTP Engine)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black">
              إدارة بوابات إرسال واتساب للمنصة
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/80 leading-relaxed">
              يتم إرسال أكواد التحقق (OTP) للطلاب واستعادة كلمات المرور فورياً عبر السحابة. المنصة تدعم كلاً من{" "}
              <strong className="text-emerald-300 font-bold">بوابة Meta الرسمية (Cloud API)</strong> والربط المباشر برقم الهاتف{" "}
              <strong className="text-emerald-300 font-mono text-base dir-ltr">{statusData?.configuredPhone || targetPhone}</strong>.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => {
                fetchStatus();
                fetchMetaConfig();
              }}
              disabled={loading || actionLoading}
              className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              <span>تحديث الحالة</span>
            </button>

            {isConnected && !isMetaActive && (
              <button
                onClick={handleLogout}
                disabled={actionLoading}
                className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/30 text-rose-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>تسجيل الخروج من الهاتف</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Alerts */}
      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          onClick={() => {
            setActiveTab("pairing_code");
            localStorage.setItem("wa_admin_active_tab", "pairing_code");
          }}
          className={`flex-1 min-w-[200px] py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === "pairing_code"
              ? "bg-white text-emerald-800 shadow-sm border border-emerald-200"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Smartphone className="w-4 h-4 text-emerald-600" />
          <span>ربط هاتف المنصة المباشر (Baileys)</span>
          {isConnected ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                متصل الآن 🟢
              </span>
            </>
          ) : (
            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black">
              اربط هاتفك من هنا 📱
            </span>
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab("meta_cloud");
            localStorage.setItem("wa_admin_active_tab", "meta_cloud");
          }}
          className={`flex-1 min-w-[200px] py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === "meta_cloud"
              ? "bg-white text-emerald-800 shadow-sm border border-emerald-200"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Globe className="w-4 h-4 text-emerald-600" />
          <span>بوابة Meta الرسمية (Cloud API)</span>
          {isMetaActive && (
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          )}
          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
            24/7 موصى بها
          </span>
        </button>

        <button
          onClick={() => {
            setActiveTab("botpress");
            localStorage.setItem("wa_admin_active_tab", "botpress");
          }}
          className={`flex-1 min-w-[200px] py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === "botpress"
              ? "bg-white text-blue-800 shadow-sm border border-blue-200"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Bot className="w-4 h-4 text-blue-600" />
          <span>محرك Botpress Cloud (Webhook)</span>
        </button>

        <button
          onClick={() => {
            setActiveTab("test_send");
            localStorage.setItem("wa_admin_active_tab", "test_send");
          }}
          className={`py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === "test_send"
              ? "bg-white text-indigo-800 shadow-sm border border-indigo-200"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Send className="w-4 h-4 text-indigo-600" />
          <span>تجربة الإرسال</span>
        </button>

        <button
          onClick={() => {
            setActiveTab("logs");
            localStorage.setItem("wa_admin_active_tab", "logs");
          }}
          className={`py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === "logs"
              ? "bg-white text-slate-800 shadow-sm border border-slate-200"
              : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Clock className="w-4 h-4 text-slate-600" />
          <span>سجل الرسائل ({statusData?.recentLogs?.length || 0})</span>
        </button>
      </div>

      {/* TAB 0: Botpress Cloud Engine */}
      {activeTab === "botpress" && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl border bg-gradient-to-br from-blue-50/90 to-indigo-50/90 border-blue-200 text-blue-950 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xs">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/20 flex items-center justify-center shrink-0">
                <Bot className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    محرك Botpress Cloud الذكي لإرسال رسائل واتساب
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    متصل ونشط
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                  تم ربط بوت Botpress السحابي بنجاح لإرسال رموز التحقق OTP للطلاب وأولياء الأمور مباشرة عبر تطبيق الواتساب، مع تفعيل ميزة محاكاة حركة &quot;جاري الكتابة&quot; الذكية لمدة 15 ثانية لتوفير الباقات وحماية حساب الواتساب من القيود.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setActiveTab("test_send");
                  localStorage.setItem("wa_admin_active_tab", "test_send");
                }}
                className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/20 flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>تجربة إرسال كود OTP الآن</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block">معرف البوت (Bot ID)</span>
              <p className="text-xs font-mono font-bold text-slate-800 break-all dir-ltr text-right">
                72f59145-c3c3-4c6b-9639-64946b690d60
              </p>
              <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>مربوط ومتحقق منه</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block">عنوان الويب هوك (Webhook URL)</span>
              <p className="text-[11px] font-mono font-bold text-slate-800 break-all dir-ltr text-right truncate">
                https://webhook.botpress.cloud/9ab5aaa2...
              </p>
              <div className="flex items-center gap-1.5 text-[11px] text-blue-600 font-bold">
                <Zap className="w-3.5 h-3.5" />
                <span>تسليم فوري مدعوم بالتوقيع الرقمي</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block">حيلة الكتابة الذكية (15s Simulation)</span>
              <p className="text-xs font-bold text-slate-800">
                مفعلة تلقائياً (Typing Indicator)
              </p>
              <div className="flex items-center gap-1.5 text-[11px] text-indigo-600 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>حماية 100% وتوفير استهلاك البوت</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: Meta Cloud API (Official) */}
      {activeTab === "meta_cloud" && (
        <div className="space-y-6">
          {/* Status Alert Banner */}
          <div
            className={`p-6 rounded-3xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              isMetaActive
                ? "bg-emerald-50/80 border-emerald-200 text-emerald-950"
                : "bg-blue-50/80 border-blue-200 text-blue-950"
            }`}
          >
            <div className="flex items-start gap-4">
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                  isMetaActive ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20" : "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                }`}
              >
                <Globe className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black">
                    {isMetaActive ? "بوابة Meta الرسمية مفعلة ومتصلة سحابياً 24/7" : "بوابة Meta WhatsApp Cloud API"}
                  </h3>
                  {isMetaActive && (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black">
                      نشطة الآن
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
                  الحل الأقوى والأكثر استقراراً للمنصات المنشورة سحابياً. يتم الإرسال من خوادم Meta مباشرةً دون الحاجة لبقاء الهاتف متصلاً بالإنترنت وبدون تأثر بتجميد سيرفرات السحابة، مع <strong>1,000 رسالة مجانية شهرياً</strong>.
                </p>
                {statusData?.metaPhoneNumberId && (
                  <p className="text-xs font-mono font-bold text-emerald-800 dir-ltr text-right">
                    Phone Number ID: {statusData.metaPhoneNumberId}
                  </p>
                )}
              </div>
            </div>

            <button
              onClick={() => setShowMetaGuide(!showMetaGuide)}
              className="px-4 py-2.5 rounded-2xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-blue-600" />
              <span>{showMetaGuide ? "إخفاء دليل التفعيل" : "كيف أفعلها مجاناً؟ (دليل 5 خطوات)"}</span>
              {showMetaGuide ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Interactive Step-by-Step Guide */}
          {showMetaGuide && (
            <div className="bg-white border-2 border-blue-200 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-5 animate-in fade-in slide-in-from-top-3">
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-blue-600" />
                    <span>دليل تفعيل WhatsApp Cloud API من شركة Meta في 5 خطوات:</span>
                  </h4>
                  <p className="text-xs text-slate-500">
                    خطوات مجانية ورسمية 100% لا تتطلب دفع أي رسوم للحصول على 1,000 رسالة شهرياً
                  </p>
                </div>
                <a
                  href="https://developers.facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-1.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <span>فتح developers.facebook.com</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    1
                  </span>
                  <h5 className="font-bold text-slate-900">إنشاء حساب مطور وتطبيق Business</h5>
                  <p className="text-slate-600 leading-relaxed">
                    ادخل على <strong className="text-blue-700">developers.facebook.com</strong> وسجل الدخول بحسابك على فيسبوك، ثم اضغط على <strong>My Apps</strong> &gt; <strong>Create App</strong> &gt; اختر النوع <strong>Other</strong> ثم <strong>Business</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    2
                  </span>
                  <h5 className="font-bold text-slate-900">إضافة منتج WhatsApp</h5>
                  <p className="text-slate-600 leading-relaxed">
                    من قائمة المنتجات، ابحث عن <strong>WhatsApp</strong> واضغط على زر <strong>Set up</strong>. سيتم نقلك مباشرة إلى لوحة تحكم WhatsApp Business.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    3
                  </span>
                  <h5 className="font-bold text-slate-900">الحصول على الرمز ومعرف الرقم (API Setup)</h5>
                  <p className="text-slate-600 leading-relaxed">
                    من القائمة الجانبية اختر <strong>API Setup</strong>. ستجد أمامك مباشرة:
                    <br />
                    • <strong>Temporary Access Token</strong> (رمز الوصول).
                    <br />
                    • <strong>Phone number ID</strong> (معرف رقم الهاتف التجريبي أو المعتمد).
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                    4
                  </span>
                  <h5 className="font-bold text-slate-900">لصق البيانات وحفظها في المنصة</h5>
                  <p className="text-slate-600 leading-relaxed">
                    انسخ الـ <strong>Access Token</strong> والـ <strong>Phone number ID</strong> وضعهما في النموذج بالأسفل، ثم اضغط <strong>حفظ وتفعيل بوابة Meta</strong>. ستعمل المنصة فوراً وتستقر للأبد!
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Configuration Form */}
          <div className="bg-white border border-slate-200 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-6">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                <Key className="w-4 h-4 text-emerald-600" />
                <span>إعدادات مفاتيح ربط Meta WhatsApp Cloud API</span>
              </h3>
              <p className="text-xs text-slate-500">
                يمكن إدخال المفاتيح هنا مباشرة لحفظها سحابياً، أو وضعها في ملف <code className="text-emerald-700 font-mono font-bold">.env</code> عبر المتغيرات: <span className="font-mono text-[11px] text-slate-600">META_WHATSAPP_TOKEN</span> و <span className="font-mono text-[11px] text-slate-600">META_WHATSAPP_PHONE_NUMBER_ID</span>.
              </p>
            </div>

            <form onSubmit={handleSaveMetaConfig} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Token */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-xs font-black text-slate-700 flex items-center justify-between">
                    <span>رمز الوصول السحابي (Access Token من Meta):</span>
                    {hasMetaTokenSaved && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 font-bold">
                        ✓ محفوظ بالفعل على السيرفر
                      </span>
                    )}
                  </label>
                  <input
                    type="password"
                    value={metaToken}
                    onChange={(e) => setMetaToken(e.target.value)}
                    placeholder={hasMetaTokenSaved ? "اتركه فارغاً للإبقاء على الرمز الحالي، أو الصق رمزاً جديداً لتحديثه" : "الصق رمز الوصول (Access Token) المنسوخ من Meta هنا"}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-xs font-mono font-bold focus:border-emerald-500 focus:outline-hidden"
                    dir="ltr"
                  />
                </div>

                {/* Phone Number ID */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-700">
                    معرف رقم الهاتف (Phone Number ID):
                  </label>
                  <input
                    type="text"
                    value={metaPhoneNumberId}
                    onChange={(e) => setMetaPhoneNumberId(e.target.value)}
                    placeholder="مثال: 1092837482910"
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-xs font-mono font-bold focus:border-emerald-500 focus:outline-hidden"
                    dir="ltr"
                  />
                </div>

                {/* WABA ID */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-700">
                    معرف حساب الأعمال (WABA ID - اختياري):
                  </label>
                  <input
                    type="text"
                    value={metaWabaId}
                    onChange={(e) => setMetaWabaId(e.target.value)}
                    placeholder="مثال: 2093847581920"
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-xs font-mono font-bold focus:border-emerald-500 focus:outline-hidden"
                    dir="ltr"
                  />
                </div>

                {/* Template Name */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-xs font-black text-slate-700 flex items-center justify-between">
                    <span>اسم القالب المعتمد (Template Name - اختياري):</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      اتركه فارغاً لإرسال رسائل نصية حرة مباشرة
                    </span>
                  </label>
                  <input
                    type="text"
                    value={metaTemplateName}
                    onChange={(e) => setMetaTemplateName(e.target.value)}
                    placeholder="مثال: otp_verification (اتركه فارغاً إن لم تنشئ قالباً بعد)"
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-xs font-mono font-bold focus:border-emerald-500 focus:outline-hidden"
                    dir="ltr"
                  />
                </div>

                {/* Webhook Info Box for Meta Configuration */}
                <div className="md:col-span-2 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                  <div className="text-xs font-black text-slate-800">
                    🔗 بيانات الـ Webhook الجاهزة للنسخ (في حال طلبها منك موقع Meta تحت قسم WhatsApp &gt; Configuration):
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-[10px] text-slate-400 font-bold block mb-0.5">عنوان URL لمعاودة الاتصال (Callback URL):</span>
                      <code className="font-mono font-bold text-indigo-700 text-[11px] break-all select-all" dir="ltr">
                        https://ais-pre-5k6r4yp6qn4gwyej4qjnhj-514857695585.europe-west2.run.app/api/webhooks/whatsapp
                      </code>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white border border-slate-200">
                      <span className="text-[10px] text-slate-400 font-bold block mb-0.5">رمز التحقق (Verify Token):</span>
                      <code className="font-mono font-bold text-emerald-700 text-[11px] select-all" dir="ltr">
                        mohamed_saber_whatsapp_verify_2027
                      </code>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 flex-wrap">
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {actionLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>حفظ وتفعيل بوابة Meta السحابية</span>
                </button>

                {(hasMetaTokenSaved || metaPhoneNumberId || statusData?.metaPhoneNumberId) && (
                  <button
                    type="button"
                    onClick={handleClearMetaConfig}
                    disabled={actionLoading}
                    className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>إلغاء ومسح إعدادات Meta (والاعتماد على الهاتف المباشر)</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setActiveTab("test_send")}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>الانتقال لتجربة الإرسال الحي</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: Pairing Code (Baileys) */}
      {activeTab === "pairing_code" && (
        <div className="space-y-6">
          {/* Dedicated Phone Number Configuration Bar */}
          <div className="bg-white border-2 border-emerald-200 rounded-[28px] p-5 sm:p-6 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <h3 className="text-sm sm:text-base font-black text-slate-900">
                  رقم واتساب المنصة للربط المباشر (Baileys)
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-mono font-bold" dir="ltr">
                  الحالي: {statusData?.configuredPhone || targetPhone}
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                يمكنك تغيير رقم هاتف واتساب المربوط بالمنصة في أي وقت. اكتب الرقم الجديد بالأسفل ثم اضغط <strong>&quot;حفظ وتغيير الرقم&quot;</strong> أو اطلب كود الربط مباشرةً.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
              <div className="relative">
                <input
                  type="tel"
                  value={targetPhone}
                  onFocus={() => setIsEditingPhone(true)}
                  onChange={(e) => {
                    setIsEditingPhone(true);
                    setTargetPhone(e.target.value);
                  }}
                  placeholder="مثال: 01012345678"
                  className="w-full sm:w-52 px-4 py-2.5 rounded-xl border-2 border-emerald-300 focus:border-emerald-600 focus:outline-hidden text-sm font-mono font-black text-center text-slate-900 bg-emerald-50/30"
                  dir="ltr"
                />
              </div>

              <button
                type="button"
                onClick={() => handleChangePhone()}
                disabled={actionLoading}
                className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                {actionLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5 text-emerald-400" />}
                <span>حفظ وتغيير الرقم</span>
              </button>

              <button
                type="button"
                onClick={() => handleChangePhone("pairing")}
                disabled={actionLoading}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black transition-all shadow-sm shadow-emerald-600/20 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                <Flame className="w-3.5 h-3.5 text-amber-300" />
                <span>تغيير الرقم + كود 8 خانات</span>
              </button>

              <button
                type="button"
                onClick={() => handleChangePhone("qr")}
                disabled={actionLoading || qrLoading}
                className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>تغيير الرقم + باركود QR (الأكثر أماناً)</span>
              </button>
            </div>
          </div>

          {/* Active Anti-Ban Shield Status Banner */}
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50/70 to-white border-2 border-emerald-400 rounded-[28px] p-5 shadow-xs space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-sm font-black text-emerald-950">
                      نظام «الرد التلقائي الآمن 100%» ضد تقييد أو حظر واتساب (Reply-Only Zero-Ban Shield)
                    </h4>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black">
                      0% خطر حظر للأبد
                    </span>
                  </div>
                  <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
                    لأن خوارزميات واتساب تقيد أي رقم يبدأ محادثات جديدة لأرقام لا تسجله في جهات اتصالها، تم تحويل محرك المنصة بالكامل إلى <strong>نظام الرد التلقائي الآمن (Inbound Trigger Reply)</strong> كما تفعل كبرى المنصات والبنوك:
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3.5 rounded-2xl bg-white border border-emerald-200/90 space-y-1">
                <div className="font-black text-emerald-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>1. الطالب أو ولي الأمر يبدأ المحادثة بضغطة زر</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  عند طلب كود التحقق، يظهر للطالب/ولي الأمر زر أخضر يفتح محادثة واتساب المنصة برسالة جاهزة: <code>&quot;تفعيل كود التحقق لمنصة مستر محمد صابر&quot;</code>، فيرسلها بضغطة واحدة.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-emerald-200/90 space-y-1">
                <div className="font-black text-emerald-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>2. المنصة ترد بالكود خلال ثانية (آمن 100%)</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  بمجرد وصول رسالة الطالب، يرد عليه السيرفر تلقائياً بكود التحقق في نفس اللحظة. <strong>الرد على شخص راسلك أولاً مسموح رسمياً في واتساب بنسبة 100% ولا يسبب أي حظر إطلاقاً!</strong>
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50/90 border border-amber-300 space-y-1">
                <div className="font-black text-amber-950 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  <span>💡 كيف تفك التقييد المؤقت من هاتفك الآن؟</span>
                </div>
                <p className="text-[11px] text-amber-900 leading-relaxed">
                  من شاشة التقييد في واتساب بهاتفك، اضغط <strong>«طلب مراجعة» (Request a review)</strong> واكتب: <em>&quot;هذا رقم خدمة عملاء ودعم طلابي للرد على استفسارات الطلاب فقط&quot;</em> وسيتم فك التقييد خلال ساعات قليلة ولن يتكرر أبداً مع النظام الجديد.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Status Indicator */}
          <div className="bg-white border border-slate-200 rounded-[32px] p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span>حالة اتصال واتساب (هاتف)</span>
            </h3>

            <div
              className={`p-5 rounded-2xl border flex flex-col items-center text-center space-y-3 ${
                isConnected
                  ? "bg-emerald-50/80 border-emerald-300 text-emerald-950"
                  : statusData?.sessionExists
                  ? "bg-amber-50/80 border-amber-300 text-amber-950"
                  : "bg-slate-50 border-slate-200 text-slate-800"
              }`}
            >
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all ${
                  isConnected
                    ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/30"
                    : statusData?.sessionExists
                    ? "bg-amber-500 text-white shadow-md shadow-amber-500/20"
                    : "bg-slate-400 text-white"
                }`}
              >
                {isConnected ? (
                  <Wifi className="w-8 h-8" />
                ) : statusData?.sessionExists ? (
                  <RefreshCw className="w-8 h-8 animate-spin" />
                ) : (
                  <WifiOff className="w-8 h-8" />
                )}
              </div>

              <div className="space-y-1">
                <span className="text-base font-black">
                  {isConnected
                    ? "الرقم متصل حقيقياً وجاهز للإرسال"
                    : statusData?.sessionExists
                    ? "جلسة مسجلة (جارٍ إعادة الاتصال...)"
                    : "الهاتف غير متصل حالياً"}
                </span>
                <p className="text-xs opacity-85 leading-relaxed">
                  {isConnected
                    ? `مرتبط بحساب واتساب نشط: +${statusData?.connectedNumber || targetPhone}`
                    : statusData?.sessionExists
                    ? "يوجد ملف جلسة محفوظ، إذا لم يتصل اضغط 'إعادة تهيئة' واطلب كود جديد"
                    : "يرجى طلب كود الربط وإدخاله في واتساب بهاتفك لتبدأ الرسائل بالوصول"}
                </p>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-slate-200 text-xs font-mono font-bold shadow-xs">
                <span>الرقم المخصص:</span>
                <strong className={isConnected ? "text-emerald-700" : "text-slate-700"}>{statusData?.configuredPhone || targetPhone}</strong>
              </div>

              {isConnected && statusData?.connectedAt && (
                <span className="text-[10px] text-emerald-700 font-bold">
                  متصل حياً منذ: {new Date(statusData.connectedAt).toLocaleTimeString("ar-EG")}
                </span>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <button
                onClick={handleRestart}
                disabled={actionLoading}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>إعادة تهيئة الجلسة</span>
              </button>

              {(isConnected || statusData?.sessionExists) && (
                <button
                  onClick={handleLogout}
                  disabled={actionLoading}
                  className="w-full py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>فصل الرقم الحالي وتسجيل الخروج</span>
                </button>
              )}
            </div>
          </div>

          {/* Pairing / QR Code Section */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-[32px] p-6 shadow-sm space-y-6">
            {/* Top Toggle: Method 1 (QR Barcode) vs Method 2 (Pairing Code 8-characters) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-600" />
                  <span>طريقة ربط واتساب بالمنصة</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  اختر الطريقة الأنسب لك لربط رقم الهاتف ({targetPhone})
                </p>
              </div>

              {/* Sub-mode switcher */}
              <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setLinkSubMode("qr")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                    linkSubMode === "qr"
                      ? "bg-white text-emerald-800 shadow-sm border border-emerald-200"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <QrCode className="w-4 h-4 text-emerald-600" />
                  <span>1. مسح الباركود (QR)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLinkSubMode("pairing")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                    linkSubMode === "pairing"
                      ? "bg-white text-emerald-800 shadow-sm border border-emerald-200"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Flame className="w-4 h-4 text-amber-500" />
                  <span>2. كود من 8 خانات</span>
                </button>
              </div>
            </div>

            {/* METHOD 1: QR CODE */}
            {linkSubMode === "qr" && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <QrCode className="w-4 h-4 text-emerald-600" />
                      <span>مسح رمز الباركود (QR Code) بكاميرا واتساب</span>
                    </h4>
                    <p className="text-xs text-slate-500">
                      امسح الباركود المباشر بكاميرا هاتفك للربط الفوري في ثوانٍ معدودة بدون كتابة أكواد
                    </p>
                  </div>

                  <button
                    onClick={handleRequestQr}
                    disabled={qrLoading || actionLoading}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer shrink-0"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${qrLoading ? "animate-spin" : ""}`} />
                    <span>{qrLoading ? "جاري توليد الباركود..." : statusData?.qrDataUrl ? "تحديث رمز الباركود" : "توليد رمز الباركود الآن"}</span>
                  </button>
                </div>

                {statusData?.qrDataUrl ? (
                  <div className="flex flex-col md:flex-row items-center justify-center gap-6 p-6 bg-slate-50/80 rounded-3xl border border-slate-200">
                    <div className="relative p-4 bg-white rounded-3xl border-2 border-emerald-500 shadow-md shrink-0">
                      <img
                        src={statusData.qrDataUrl}
                        alt="WhatsApp QR Code"
                        className="w-56 h-56 sm:w-64 sm:h-64 object-contain rounded-xl"
                      />
                      <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-emerald-600 pointer-events-none" />
                      <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-emerald-600 pointer-events-none" />
                      <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-emerald-600 pointer-events-none" />
                      <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-emerald-600 pointer-events-none" />
                    </div>

                    <div className="space-y-3 max-w-sm text-xs text-slate-700">
                      <div className="font-black text-slate-900 text-sm flex items-center gap-2">
                        <Camera className="w-4 h-4 text-emerald-600" />
                        <span>خطوات المسح بكاميرا واتساب:</span>
                      </div>
                      <ol className="list-decimal list-inside space-y-2 leading-relaxed font-medium">
                        <li>افتح تطبيق <strong>واتساب</strong> على هاتفك <strong>({targetPhone})</strong>.</li>
                        <li>اضغط على القائمة (⋮) أو <strong>الإعدادات</strong>.</li>
                        <li>اختر <strong>الأجهزة المرتبطة (Linked Devices)</strong>.</li>
                        <li>اضغط على <strong>&quot;ربط جهاز&quot; (Link a device)</strong>.</li>
                        <li>وجّه كاميرا الهاتف نحو مربع الباركود الظاهر هنا.</li>
                      </ol>
                      <div className="pt-2">
                        <span className="inline-block text-[11px] text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                          💡 يتجدد الباركود دورياً لأمان الاتصال، إذا انتهت مهلته اضغط زر &quot;تحديث رمز الباركود&quot;.
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center space-y-4 bg-emerald-50/50 rounded-3xl border-2 border-dashed border-emerald-300">
                    <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center shadow-inner">
                      <QrCode className="w-8 h-8" />
                    </div>
                    <div className="space-y-1 max-w-md mx-auto">
                      <h4 className="text-base font-black text-slate-900">رمز الباركود (QR Code)</h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        اضغط على الزر بالأسفل لتوليد رمز الباركود لمسحه بكاميرا واتساب بهاتفك فورياً.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleRequestQr}
                      disabled={qrLoading}
                      className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2 mx-auto cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                    >
                      <RefreshCw className={`w-4 h-4 ${qrLoading ? "animate-spin" : ""}`} />
                      <span>{qrLoading ? "جاري توليد الباركود..." : "توليد رمز الباركود الآن (QR Code)"}</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* METHOD 2: PAIRING CODE (8 CHARACTERS) */}
            {linkSubMode === "pairing" && (
              <div className="space-y-5">
                {/* Clarification banner */}
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-amber-950 text-xs flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <strong className="font-black text-amber-900 block">توضيح هام جداً بخصوص رقم الهاتف وكود الربط:</strong>
                    <p className="text-amber-800 leading-relaxed">
                      رقم هاتف المنصة هو <strong>{targetPhone}</strong> (11 رقماً محلياً أو 12 رقماً بالصيغة الدولية <strong>+20{targetPhone.replace(/^0+/, "")}</strong>).
                      <br />
                      <strong>كود الربط ليس رقم الهاتف!</strong> بل هو كود مكوّن من <strong>8 خانات فقط</strong> (أحرف وأرقام مثل: <code className="bg-white/90 px-1.5 py-0.5 rounded font-mono font-black text-emerald-800">8E1B-F64J</code>) يظهر بالأسفل وتدخله في تطبيق واتساب بهاتفك.
                    </p>
                  </div>
                </div>

                {/* Target Phone Input */}
                <div className="flex flex-col sm:flex-row items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="text-xs text-slate-700 font-bold whitespace-nowrap">رقم هاتف المنصة:</div>
                  <div className="flex items-center gap-2 flex-1 w-full sm:w-auto">
                    <input
                      type="tel"
                      value={targetPhone}
                      onFocus={() => setIsEditingPhone(true)}
                      onChange={(e) => {
                        setIsEditingPhone(true);
                        setTargetPhone(e.target.value);
                      }}
                      placeholder="مثال: 01012345678"
                      className="flex-1 sm:w-48 px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono text-center font-bold bg-white"
                      dir="ltr"
                    />
                    <button
                      onClick={handleRequestPairingCode}
                      disabled={actionLoading}
                      className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black transition-all shadow-xs flex items-center gap-2 cursor-pointer shrink-0"
                    >
                      {actionLoading ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <Smartphone className="w-4 h-4" />
                      )}
                      <span>{actionLoading ? "جاري التوليد من واتساب..." : "توليد كود الربط (8 خانات)"}</span>
                    </button>
                  </div>
                </div>

                {pairingCode && pairingCode !== "ALREADY_PAIRED" && pairingCode !== "CONNECTED" ? (
                  <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-slate-50 border-2 border-dashed border-emerald-400 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-900 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping inline-block" />
                        <span>كود الربط المكون من 8 خانات لرقمك:</span>
                      </span>
                      {timeLeft > 0 ? (
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-100/80 px-2.5 py-0.5 rounded-full font-mono">
                          صالح لمدة: {timeLeft} ثانية
                        </span>
                      ) : (
                        <button
                          onClick={handleRequestPairingCode}
                          className="text-xs font-bold text-amber-700 underline cursor-pointer"
                        >
                          انتهى الوقت - اضغط لتوليد كود جديد
                        </button>
                      )}
                    </div>

                    {/* 8 Distinct character boxes */}
                    <div className="flex flex-col items-center justify-center gap-3 py-3">
                      <div className="flex flex-wrap items-center justify-center gap-2 font-mono" dir="ltr">
                        {pairingCode.replace(/-/g, "").split("").slice(0, 4).map((char, i) => (
                          <div
                            key={i}
                            className="w-10 h-14 sm:w-12 sm:h-16 rounded-2xl bg-white border-2 border-emerald-500 shadow-md flex items-center justify-center text-2xl sm:text-3xl font-black text-emerald-700 select-all"
                          >
                            {char}
                          </div>
                        ))}
                        <span className="text-2xl sm:text-3xl font-black text-emerald-400 px-1">—</span>
                        {pairingCode.replace(/-/g, "").split("").slice(4, 8).map((char, i) => (
                          <div
                            key={i + 4}
                            className="w-10 h-14 sm:w-12 sm:h-16 rounded-2xl bg-white border-2 border-emerald-500 shadow-md flex items-center justify-center text-2xl sm:text-3xl font-black text-emerald-700 select-all"
                          >
                            {char}
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <button
                          onClick={copyPairingCode}
                          className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                        >
                          {copied ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
                          <span>{copied ? "تم نسخ الكود!" : "نسخ الكود"}</span>
                        </button>
                        <button
                          onClick={handleRequestPairingCode}
                          disabled={actionLoading}
                          className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${actionLoading ? "animate-spin" : ""}`} />
                          <span>طلب كود جديد</span>
                        </button>
                      </div>
                    </div>

                    {/* Step-by-step instructions */}
                    <div className="bg-white rounded-2xl p-5 border border-emerald-200 shadow-xs space-y-2 text-xs text-slate-700">
                      <p className="font-black text-slate-900 flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">✓</span>
                        <span>خطوات إدخال الكود في واتساب على هاتفك ({targetPhone}):</span>
                      </p>
                      <ol className="list-decimal list-inside space-y-1.5 text-slate-700 leading-relaxed pr-2 font-medium">
                        <li>افتح تطبيق <strong>واتساب (WhatsApp)</strong> على هاتفك <strong>{targetPhone}</strong></li>
                        <li>اضغط على الإعدادات &gt; <strong>الأجهزة المرتبطة (Linked Devices)</strong></li>
                        <li>اضغط على <strong>ربط جهاز (Link a Device)</strong></li>
                        <li>اضغط بالأسفل على: <strong>&quot;الربط برقم الهاتف بدلاً من ذلك&quot; (Link with phone number instead)</strong></li>
                        <li>أدخل الكود المكون من 8 خانات الظاهر أعلاه: <strong className="font-mono text-emerald-700 text-sm font-black bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">{pairingCode}</strong></li>
                        <li>بمجرد كتابته، سيتعرف السيرفر على الهاتف فوراً وتتحول الحالة إلى <strong className="text-emerald-600">&quot;متصل&quot;</strong>.</li>
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 rounded-3xl bg-gradient-to-br from-emerald-50 via-teal-50 to-white border-2 border-emerald-300/80 text-center space-y-4 shadow-sm">
                    <div className="w-16 h-16 rounded-3xl bg-emerald-600 text-white mx-auto flex items-center justify-center shadow-lg shadow-emerald-600/20">
                      <Smartphone className="w-8 h-8" />
                    </div>
                    <div className="space-y-1 max-w-md mx-auto">
                      <h4 className="text-base font-black text-slate-900">
                        كود الربط السريع (Pairing Code) لهاتف {targetPhone}
                      </h4>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        اضغط على الزر بالأسفل لتوليد كود مكون من 8 خانات فقط وإدخاله في واتساب بهاتفك بدون الحاجة للمسح بالكاميرا.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleRequestPairingCode}
                      disabled={actionLoading}
                      className="px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-black transition-all shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 mx-auto cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                    >
                      {actionLoading ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري الاتصال بسيرفرات واتساب وتوليد الكود...</span>
                        </>
                      ) : (
                        <>
                          <Smartphone className="w-4 h-4" />
                          <span>توليد كود الربط (8 خانات)</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
          </div>
        </div>
      )}

      {/* TAB 3: Test Send */}
      {activeTab === "test_send" && (
        <div className="bg-white border border-slate-200 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
              <Send className="w-4 h-4 text-indigo-600" />
              <span>تجربة إرسال رسالة واتساب حية (Live Test)</span>
            </h3>
            <p className="text-xs text-slate-500">
              أدخل أي رقم هاتف محمول لتجربة وصول رمز التحقق والتأكد من نجاح الإرسال عبر المزود الفعّال حالياً
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-600 font-bold">مزود الإرسال النشط حالياً:</span>
              <span className="px-3 py-1 rounded-full text-xs font-black bg-white border shadow-2xs text-slate-800">
                {statusData?.activeProvider === "meta_cloud_api"
                  ? "🌐 بوابة Meta WhatsApp Cloud API الرسمية (متصل)"
                  : statusData?.activeProvider === "baileys_socket"
                  ? `📱 هاتف المنصة المتصل مباشرة (+${statusData?.connectedNumber || targetPhone})`
                  : statusData?.activeProvider === "gateway"
                  ? "🚀 بوابة واتساب السحابية الخارجية"
                  : "⚠️ الهاتف غير مربوط بعد (يرجى ربط رقم 01551955096 بالباركود أو كود الـ 8 خانات)"}
              </span>
            </div>
            {statusData?.activeProvider !== "baileys_socket" && statusData?.activeProvider !== "meta_cloud_api" && (
              <button
                type="button"
                onClick={() => {
                  setActiveTab("pairing_code");
                  localStorage.setItem("wa_admin_active_tab", "pairing_code");
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Smartphone className="w-4 h-4" />
                <span>اضغط هنا لربط هاتف المنصة الآن</span>
              </button>
            )}
          </div>

          <form onSubmit={handleTestSend} className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <input
                type="text"
                value={testPhone}
                onChange={(e) => setTestPhone(e.target.value)}
                placeholder="مثال: 01551955096 أو 01040672314"
                className="w-full pl-4 pr-10 py-3.5 rounded-2xl border border-slate-200 text-xs font-mono font-bold focus:border-indigo-500 focus:outline-hidden"
                dir="ltr"
              />
              <PhoneCall className="w-4 h-4 text-slate-400 absolute right-3.5 top-4" />
            </div>

            <button
              type="submit"
              disabled={actionLoading}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              {actionLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span>إرسال كود تجريبي الآن</span>
            </button>
          </form>

          {testResult && (
            <div
              className={`p-5 rounded-2xl text-xs space-y-2 border ${
                testResult.success && testResult.result?.deliveredDirectly
                  ? "bg-emerald-50 border-emerald-300 text-emerald-950"
                  : "bg-rose-50 border-rose-300 text-rose-950"
              }`}
            >
              <p className="font-bold flex items-center gap-2">
                {testResult.success && testResult.result?.deliveredDirectly ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <span className="text-sm">{testResult.message}</span>
              </p>

              {testResult.error && (
                <p className="p-2.5 rounded-xl bg-rose-100/80 border border-rose-200 text-rose-800 font-semibold leading-relaxed">
                  {testResult.error}
                </p>
              )}

              <div className="pt-2 border-t border-black/5 flex flex-wrap items-center justify-between gap-2 font-mono text-[11px]">
                <span>الرمز المولد: <strong>[{testResult.otp}]</strong></span>
                <span className={testResult.result?.deliveredDirectly ? "text-emerald-700 font-bold" : "text-rose-700 font-bold"}>
                  حالة التسليم الفعلي: {testResult.result?.deliveredDirectly ? "✅ تم التسليم لهاتف المستلم بنجاح!" : "❌ لم تصل الرسالة (واتساب غير متصل بهاتف حقيقي)"}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: Logs */}
      {activeTab === "logs" && (
        <div className="bg-white border border-slate-200 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-600" />
                <span>سجل رسائل OTP المرسلة عبر واتساب</span>
              </h3>
              <p className="text-xs text-slate-500">
                آخر العمليات والطلبات التي تمت على المنصة مع الأكواد وحالة كل رسالة
              </p>
            </div>

            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-xl">
              {statusData?.recentLogs?.length || 0} عملية
            </span>
          </div>

          {statusData?.recentLogs && statusData.recentLogs.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-bold">
                    <th className="pb-3 pr-2">الوقت</th>
                    <th className="pb-3">هاتف الطالب</th>
                    <th className="pb-3 text-center">رمز OTP</th>
                    <th className="pb-3">الحالة</th>
                    <th className="pb-3">التفاصيل والمزود</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {statusData.recentLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 pr-2 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString("ar-EG")}
                      </td>
                      <td className="py-3 font-mono font-bold text-slate-900 dir-ltr text-right">
                        {log.phone}
                      </td>
                      <td className="py-3 text-center">
                        <span className="font-mono font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                          {log.otp}
                        </span>
                      </td>
                      <td className="py-3">
                        {log.status === "sent_meta_cloud" ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                            <Globe className="w-3 h-3" />
                            <span>Meta Cloud API</span>
                          </span>
                        ) : log.status === "sent_direct" ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>مرسل بالهاتف</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                            <Clock className="w-3 h-3" />
                            <span>في الانتظار</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3 text-slate-500 text-[11px] max-w-xs truncate">
                        {log.message}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-8 text-center text-slate-400 text-xs">
              لا توجد رسائل OTP مسجلة في الجلسة حتى الآن.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
