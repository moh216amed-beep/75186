import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global monkey-patch for JSON.stringify to prevent circular structure crashes across any component or event
const nativeStringify = JSON.stringify;
JSON.stringify = function (value: any, replacer?: any, space?: any) {
  try {
    return nativeStringify.call(this, value, replacer, space);
  } catch (err: any) {
    if (err && String(err?.message || '').toLowerCase().includes('circular')) {
      const seen = new WeakSet();
      try {
        return nativeStringify.call(
          this,
          value,
          (key: string, val: any) => {
            if (typeof val === 'object' && val !== null) {
              if (
                (typeof Element !== 'undefined' && val instanceof Element) ||
                (typeof Node !== 'undefined' && val instanceof Node) ||
                (typeof Window !== 'undefined' && val instanceof Window) ||
                (typeof Document !== 'undefined' && val instanceof Document) ||
                (typeof Event !== 'undefined' && val instanceof Event) ||
                ('target' in val && 'nativeEvent' in val) ||
                ('stateNode' in val && 'return' in val) ||
                key.startsWith('__react') ||
                key.startsWith('_react') ||
                seen.has(val)
              ) {
                return undefined;
              }
              seen.add(val);
            }
            if (typeof replacer === 'function') {
              return replacer(key, val);
            }
            return val;
          },
          space
        );
      } catch {
        return 'null';
      }
    }
    throw err;
  }
} as typeof JSON.stringify;

// Guard HTMLVideoElement.prototype.requestPictureInPicture against calling before metadata loads
if (typeof window !== 'undefined' && typeof HTMLVideoElement !== 'undefined') {
  const originalRequestPiP = HTMLVideoElement.prototype.requestPictureInPicture;
  if (originalRequestPiP) {
    HTMLVideoElement.prototype.requestPictureInPicture = async function (this: HTMLVideoElement) {
      // If metadata has not loaded yet (readyState < HAVE_METADATA = 1) or PiP is disabled, gracefully avoid uncaught exception
      if (this.disablePictureInPicture || this.readyState < 1) {
        console.warn('requestPictureInPicture skipped: video metadata not loaded yet or PiP disabled.');
        return new Promise<PictureInPictureWindow>((_, reject) => {
          // Return a handled rejection or resolve dummy if supported
          try {
            if (this.readyState >= 1 && !this.disablePictureInPicture) {
              originalRequestPiP.call(this).then(_).catch(reject);
            } else {
              const notReadyErr = new DOMException('Metadata for the video element are not loaded yet.', 'InvalidStateError');
              reject(notReadyErr);
            }
          } catch (syncErr) {
            reject(syncErr);
          }
        }).catch((err) => {
          // Ensure the promise chain itself handles the error silently
          console.warn('Handled PiP request promise rejection:', err?.message || err);
          return null as unknown as PictureInPictureWindow;
        });
      }
      try {
        return await originalRequestPiP.call(this);
      } catch (err: any) {
        console.warn('Handled PiP call failure:', err?.message || err);
        return null as unknown as PictureInPictureWindow;
      }
    };
  }

  // Global unhandled promise rejection handler
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const msg = String(reason?.message || reason || '');
    const isSyntheticEvent =
      reason instanceof Event ||
      (reason && typeof reason === 'object' && 'isTrusted' in reason && !('message' in reason));
    const isPiPMetadataError =
      msg.includes('Metadata for the video element are not loaded yet') ||
      msg.includes('requestPictureInPicture') ||
      reason?.name === 'InvalidStateError';
    const isCircularJsonError =
      msg.includes('Converting circular structure to JSON') ||
      msg.includes('circular structure') ||
      msg.includes('__reactFiber');

    if (isSyntheticEvent || isPiPMetadataError || isCircularJsonError) {
      event.preventDefault();
      event.stopImmediatePropagation();
      console.warn('Handled rejection gracefully:', msg);
    }
  });

  // Global window error handler for uncaught exceptions including PiP error and circular JSON errors
  window.addEventListener(
    'error',
    (event) => {
      const msg = String(event.message || '');
      const isCircularJsonError =
        msg.includes('Converting circular structure to JSON') ||
        msg.includes('circular structure') ||
        msg.includes('__reactFiber');

      if (
        isCircularJsonError ||
        msg.includes('Metadata for the video element are not loaded yet') ||
        msg.includes('requestPictureInPicture') ||
        (event.target &&
          (event.target instanceof HTMLMediaElement ||
            event.target instanceof HTMLImageElement ||
            event.target instanceof HTMLScriptElement))
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        console.warn('Handled uncaught error gracefully:', msg);
        return true;
      }
    },
    true
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
