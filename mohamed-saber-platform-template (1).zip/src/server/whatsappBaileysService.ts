import * as Baileys from "@whiskeysockets/baileys";
import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  WASocket,
  ConnectionState,
  Browsers,
} from "@whiskeysockets/baileys";
import pino from "pino";
import QRCode from "qrcode";
import path from "path";
import fs from "fs";
import axios from "axios";
import { sendOtpToWhatsApp, BOTPRESS_CONFIG } from "./botpressWhatsappService";

/**
 * Safe factory to create Baileys socket across ESM/CJS bundlers and production builds.
 * Solves the (0, import_baileys.default) is not a function runtime error.
 */
function safeMakeWASocket(options: any): WASocket {
  const candidate =
    (typeof Baileys.makeWASocket === "function" && Baileys.makeWASocket) ||
    (typeof (Baileys as any).default === "function" && (Baileys as any).default) ||
    (typeof (Baileys as any).default?.default === "function" && (Baileys as any).default.default) ||
    (typeof (Baileys as any).default?.makeWASocket === "function" && (Baileys as any).default.makeWASocket) ||
    (typeof makeWASocket === "function" && makeWASocket) ||
    (typeof (makeWASocket as any)?.default === "function" && (makeWASocket as any).default) ||
    (typeof (makeWASocket as any)?.makeWASocket === "function" && (makeWASocket as any).makeWASocket);

  if (typeof candidate === "function") {
    return candidate(options);
  }
  throw new Error("تعذر تهيئة مكتبة Baileys: دالة makeWASocket غير متاحة كدالة قابلة للاستدعاء.");
}

/**
 * Service for sending WhatsApp OTP using Baileys integration
 * منصة مستر محمد صابر التعليمية
 * الرقم المخصص لمنصة مستر محمد صابر: 01551955096 (201551955096)
 */

export const DEFAULT_PLATFORM_PHONE = process.env.WHATSAPP_SENDER_PHONE || "01551955096";
const AUTH_DIR = path.resolve(process.cwd(), "whatsapp_session_auth");
const WA_CONFIG_FILE = path.resolve(process.cwd(), "data", "whatsapp_config.json");

function loadSavedPlatformPhone(): string {
  try {
    if (fs.existsSync(WA_CONFIG_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(WA_CONFIG_FILE, "utf8"));
      if (parsed && typeof parsed.configuredPhone === "string" && parsed.configuredPhone.trim()) {
        const saved = parsed.configuredPhone.trim();
        if (saved === "01508616572" || saved === "201508616572") {
          return DEFAULT_PLATFORM_PHONE;
        }
        return saved;
      }
    }
  } catch {}
  return DEFAULT_PLATFORM_PHONE;
}

function savePlatformPhoneToDisk(phone: string): void {
  try {
    const dir = path.dirname(WA_CONFIG_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    let existing: Record<string, any> = {};
    if (fs.existsSync(WA_CONFIG_FILE)) {
      try {
        existing = JSON.parse(fs.readFileSync(WA_CONFIG_FILE, "utf8")) || {};
      } catch {}
    }
    existing.configuredPhone = phone.trim();
    existing.updatedAt = new Date().toISOString();
    fs.writeFileSync(WA_CONFIG_FILE, JSON.stringify(existing, null, 2), "utf8");
  } catch (e) {
    console.warn("Could not save WhatsApp configuredPhone to disk:", e);
  }
}

export interface SendOtpResult {
  success: boolean;
  messageId?: string;
  phone?: string;
  deliveredDirectly?: boolean;
  requiresUserInitiatedChat?: boolean;
  whatsappTriggerLink?: string;
  platformWhatsAppPhone?: string;
  error?: string;
}

export interface PendingOtpRecord {
  phone: string;
  formattedPhone: string;
  otp: string;
  messageText: string;
  createdAt: number;
  expiresAt: number;
  delivered: boolean;
}

export interface WhatsAppLogEntry {
  id: string;
  timestamp: string;
  phone: string;
  otp: string;
  status: "sent_direct" | "sent_reply_safe" | "sent_gateway" | "sent_meta_cloud" | "sent_botpress" | "queued_offline" | "awaiting_user_message";
  message: string;
}

export interface MetaCloudConfig {
  token?: string;
  phoneNumberId?: string;
  wabaId?: string;
  templateName?: string;
}

export interface WhatsAppConnectionStatus {
  configuredPhone: string;
  formattedPhone: string;
  status: "connected" | "connecting" | "qr_ready" | "pairing_code_ready" | "disconnected";
  isConnected: boolean;
  isBaileysConnected: boolean;
  connectedNumber: string | null;
  connectedAt: string | null;
  qrDataUrl: string | null;
  pairingCode: string | null;
  lastError: string | null;
  lastMetaError?: string | null;
  sessionExists: boolean;
  recentLogs: WhatsAppLogEntry[];
  metaCloudApiConfigured: boolean;
  metaPhoneNumberId?: string | null;
  botpressConfigured?: boolean;
  botpressBotId?: string;
  botpressWebhookUrl?: string;
  activeProvider: "botpress_cloud" | "meta_cloud_api" | "baileys_socket" | "gateway" | "offline";
  zeroBanReplyMode: boolean;
  knownChattedCount: number;
}

/**
 * Normalize and format phone number for WhatsApp E.164 standard
 * (Converts Egypt local 01xxxxxxxxx to 201xxxxxxxxx)
 */
export function formatWhatsAppPhone(phone: string): string {
  let cleaned = String(phone || "").trim().replace(/[\s\-\(\)\+]/g, "");

  if (cleaned.startsWith("00")) {
    cleaned = cleaned.slice(2);
  }

  // Egyptian local numbers starting with 01
  if (cleaned.startsWith("01") && cleaned.length === 11) {
    cleaned = "2" + cleaned;
  } else if (cleaned.startsWith("1") && cleaned.length === 10) {
    cleaned = "20" + cleaned;
  } else if (
    !cleaned.startsWith("20") &&
    (cleaned.startsWith("010") ||
      cleaned.startsWith("011") ||
      cleaned.startsWith("012") ||
      cleaned.startsWith("015"))
  ) {
    cleaned = "2" + cleaned;
  }

  return cleaned;
}

/**
 * Build a direct wa.me link where the student/parent sends a 1-click trigger message to the platform number.
 * When the student sends this message, WhatsApp registers it as a User-Initiated Conversation,
 * which makes our automated reply 100% immune to WhatsApp "cold outreach / restriction" bans!
 */
export function buildWhatsAppTriggerLink(platformPhone: string, triggerText?: string): string {
  const formattedPlatform = formatWhatsAppPhone(platformPhone || DEFAULT_PLATFORM_PHONE);
  const text = encodeURIComponent(
    triggerText || "مرحباً منصة مستر محمد صابر، أرسل لي كود التحقق الخاص بي 🔐"
  );
  return `https://wa.me/${formattedPlatform}?text=${text}`;
}

/**
 * Generate natural human-like WhatsApp OTP message text (Anti-Ban)
 * Avoids identical bulk templates and removes bot-like random hash tags at the end.
 */
export function generateOtpMessage(otp: string): string {
  const greetings = [
    "أهلاً بك في منصة مستر محمد صابر التعليمية 🎓",
    "مرحباً بك يا بطل في منصة مستر محمد صابر 🌟",
    "حياك الله في منصة مستر محمد صابر التعليمية 📚",
    "أهلاً وسهلاً بك في منصة مستر محمد صابر 👋",
  ];
  const bodies = [
    `كود التأكيد الخاص بحسابك هو: *${otp}*`,
    `رمز التحقق لتفعيل حسابك في المنصة: *${otp}*`,
    `كود الدخول السري الخاص بك هو: *${otp}*`,
    `رمز التفعيل المؤقت لحسابك: *${otp}*`,
  ];
  const footers = [
    "الكود صالح لمدة 5 دقائق، نتمنى لك كل التوفيق والنجاح.",
    "يرجى إدخال الرمز في المنصة خلال 5 دقائق. بالتوفيق!",
    "هذا الرمز خاص بك وصالح لمدة 5 دقائق فقط.",
    "مع خالص تمنيات أسرة مستر محمد صابر لك بالتفوق.",
  ];

  const g = greetings[Math.floor(Math.random() * greetings.length)];
  const b = bodies[Math.floor(Math.random() * bodies.length)];
  const f = footers[Math.floor(Math.random() * footers.length)];

  return `${g}\n\n${b}\n\n${f}`;
}

const KNOWN_CHATS_FILE = path.resolve(process.cwd(), "data", "whatsapp_known_chats.json");

function loadKnownChattedPhones(): Set<string> {
  try {
    if (fs.existsSync(KNOWN_CHATS_FILE)) {
      const arr = JSON.parse(fs.readFileSync(KNOWN_CHATS_FILE, "utf8"));
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch {}
  return new Set();
}

function saveKnownChattedPhones(set: Set<string>): void {
  try {
    const dir = path.dirname(KNOWN_CHATS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(KNOWN_CHATS_FILE, JSON.stringify(Array.from(set), null, 2), "utf8");
  } catch {}
}

class WhatsAppBaileysManager {
  private sock: WASocket | null = null;
  private status: "connected" | "connecting" | "qr_ready" | "pairing_code_ready" | "disconnected" = "disconnected";
  private connectedNumber: string | null = null;
  private connectedAt: string | null = null;
  private qrDataUrl: string | null = null;
  private pairingCode: string | null = null;
  private lastError: string | null = null;
  private isInitializing = false;
  private initPromise: Promise<void> | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private recentLogs: WhatsAppLogEntry[] = [];
  private retryCount = 0;
  private configuredPhone = loadSavedPlatformPhone();
  private sendQueue: Promise<any> = Promise.resolve();
  private lastMessageSentAt = 0;
  private lastPairingRequestedAt = 0;
  // Zero-Ban Reply-Only Engine: Stores phones that have already messaged us (User-Initiated Chat)
  private knownUserInitiatedPhones: Set<string> = loadKnownChattedPhones();
  // Pending OTPs waiting for the student/parent to send a trigger message on WhatsApp
  private pendingOtpsByPhone: Map<string, PendingOtpRecord> = new Map();
  // Anti-Ban Rate Limiting & Recipient Cooldown Tracking
  private recipientLastSentMap: Map<string, number> = new Map();
  private hourlySentTimestamps: number[] = [];
  private maxMessagesPerHour = 25;
  private minRecipientCooldownMs = 45 * 1000; // 45 seconds between messages to the same number
  private metaConfig: MetaCloudConfig = {
    token: process.env.META_WHATSAPP_TOKEN || process.env.WHATSAPP_CLOUD_API_TOKEN || "",
    phoneNumberId: process.env.META_WHATSAPP_PHONE_NUMBER_ID || process.env.WHATSAPP_PHONE_NUMBER_ID || "",
    wabaId: process.env.META_WHATSAPP_WABA_ID || "",
    templateName: process.env.META_WHATSAPP_TEMPLATE_NAME || "",
  };

  /**
   * Anti-Ban Safe Socket Configuration
   * Uses official Browsers.ubuntu("Chrome") signature (["Ubuntu", "Chrome", "22.04.4"]) required by WhatsApp Web
   * for both Pairing Code (8-digit) and QR Code, with passive sync and zero bot footprints to protect the number from any ban.
   */
  private createAntiBanSocketConfig(version: any, state: any, logger: any) {
    const browserSignature =
      typeof Browsers?.ubuntu === "function"
        ? Browsers.ubuntu("Chrome")
        : (["Ubuntu", "Chrome", "22.04.4"] as [string, string, string]);
    return {
      version,
      auth: state,
      logger,
      printQRInTerminal: false,
      // Authentic Chrome Web browser fingerprint (required by WhatsApp for 8-digit phone number pairing + QR + anti-ban)
      browser: browserSignature,
      // Never stay "Online" 24/7 (bots that stay online 24/7 get banned rapidly)
      markOnlineOnConnect: false,
      // Never pull full chat history on link (massive history sync after pairing triggers instant ban)
      syncFullHistory: false,
      shouldSyncHistoryMessage: () => false,
      // Avoid generating link previews or emitting unnecessary own events
      generateHighQualityLinkPreview: false,
      emitOwnEvents: false,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 60000,
      keepAliveIntervalMs: 45000,
      retryRequestDelayMs: 5000,
    };
  }

  constructor() {
    if (!fs.existsSync(AUTH_DIR)) {
      try {
        fs.mkdirSync(AUTH_DIR, { recursive: true });
      } catch (err) {
        console.warn("Could not create whatsapp_session_auth directory:", err);
      }
    }
    // Ensure configuredPhone is persisted
    savePlatformPhoneToDisk(this.configuredPhone);
  }

  public async init(targetPhone?: string): Promise<void> {
    if (targetPhone) {
      this.configuredPhone = targetPhone;
    }

    if (this.sock && this.status === "connected") {
      return;
    }

    if (this.initPromise) {
      return this.initPromise;
    }

    this.isInitializing = true;
    this.status = "connecting";
    this.lastError = null;

    this.initPromise = (async () => {
      try {
        console.log("🔄 [WhatsApp Anti-Ban Engine] جاري تهيئة جلسة واتساب آمنة لمنصة مستر محمد صابر...");

        const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

        // Fetch version with 3.5-second timeout to avoid network hanging
        const { version } = await Promise.race([
          fetchLatestBaileysVersion(),
          new Promise<{ version: [number, number, number] }>((_, reject) =>
            setTimeout(() => reject(new Error("version timeout")), 3500)
          ),
        ]).catch(() => ({ version: [2, 3000, 1043857760] as any }));

        const logger = pino({ level: "silent" });

        const sock = safeMakeWASocket(this.createAntiBanSocketConfig(version, state, logger));

        this.sock = sock;
        this.bindSocketEvents(sock, saveCreds, state);
      } catch (err: any) {
        this.status = "disconnected";
        this.lastError = err?.message || String(err);
        console.error("❌ [WhatsApp Baileys] خطأ أثناء تشغيل العميل:", err);
      } finally {
        this.isInitializing = false;
        this.initPromise = null;
      }
    })();

    return this.initPromise;
  }

  /**
   * Check if a valid registered session exists.
   * Note: QR pairing sets `account` and `me.id` in creds.json without setting `registered: true`,
   * whereas 8-digit pairing sets `me.id` early (before user enters the code) and sets `registered: true` or `account` only after confirmation.
   * Therefore a session is genuinely paired if `me.id` exists AND (`registered === true` OR `account` exists).
   */
  public isSessionRegistered(): boolean {
    try {
      const credsPath = path.join(AUTH_DIR, "creds.json");
      if (fs.existsSync(credsPath)) {
        const raw = fs.readFileSync(credsPath, "utf-8");
        const parsed = JSON.parse(raw);
        return Boolean(parsed?.me?.id && (parsed?.registered === true || parsed?.account));
      }
    } catch {}
    return false;
  }

  /**
   * Helper to inspect saved creds.json and extract registered phone number
   */
  public getSavedRegisteredPhone(): string | null {
    try {
      const credsPath = path.join(AUTH_DIR, "creds.json");
      if (fs.existsSync(credsPath)) {
        const raw = fs.readFileSync(credsPath, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed?.me?.id && (parsed?.registered === true || parsed?.account)) {
          const meId = parsed.me.id;
          const clean = meId.split(":")[0] || meId.split("@")[0];
          if (clean) return clean;
        }
      }
    } catch {}
    return null;
  }

  /**
   * Explicitly generate / refresh a QR code for camera scanning
   */
  public async requestQrCode(newPhone?: string): Promise<{ success: boolean; qrDataUrl?: string; error?: string }> {
    if (newPhone && newPhone.trim()) {
      const cleanNew = formatWhatsAppPhone(newPhone.trim());
      const cleanOld = formatWhatsAppPhone(this.configuredPhone);
      this.configuredPhone = newPhone.trim();
      savePlatformPhoneToDisk(this.configuredPhone);
      if (cleanNew !== cleanOld) {
        await this.logout();
      }
    }

    if (this.status === "connected" && this.sock) {
      return { success: false, error: "الرقم متصل بالفعل بمنصة مستر محمد صابر! لتغيير الرقم اضغط على زر تغيير الرقم أولاً." };
    }

    // If a QR code is already active on an open socket, return it immediately or wait for the next rotation
    // without tearing down the socket (preventing rapid socket creation bans)
    if (this.sock && this.status === "qr_ready" && this.qrDataUrl) {
      return { success: true, qrDataUrl: this.qrDataUrl };
    }

    if (this.isSessionRegistered()) {
      const savedPhone = this.getSavedRegisteredPhone();
      const targetClean = formatWhatsAppPhone(this.configuredPhone);
      if (savedPhone && savedPhone !== targetClean) {
        await this.logout();
      } else {
        // Try reconnecting existing valid session first
        this.init().catch(() => {});
        return {
          success: false,
          error: `يوجد جلسة واتساب مسجلة بالفعل للرقم (+${savedPhone}) وجارٍ الاتصال بها تلقائياً. إذا أردت مسح باركود جديد، اضغط على "فصل الرقم الحالي" أولاً.`,
        };
      }
    }

    try {
      console.log("📲 [WhatsApp Baileys] جاري تهيئة باركود QR جديد لمسحه بكاميرا الهاتف...");
      this.clearSessionAuth();
      this.pairingCode = null;
      this.qrDataUrl = null;
      this.status = "connecting";

      if (this.sock) {
        try {
          this.sock.ev.removeAllListeners("creds.update");
          this.sock.ev.removeAllListeners("connection.update");
          this.sock.ev.removeAllListeners("messages.upsert");
          this.sock.end(undefined);
        } catch {}
        this.sock = null;
      }

      await new Promise((r) => setTimeout(r, 300));

      const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
      const { version } = await Promise.race([
        fetchLatestBaileysVersion(),
        new Promise<{ version: [number, number, number] }>((_, reject) =>
          setTimeout(() => reject(new Error("version timeout")), 3500)
        ),
      ]).catch(() => ({ version: [2, 3000, 1043857760] as any }));
      const logger = pino({ level: "silent" });

      const sock = safeMakeWASocket(this.createAntiBanSocketConfig(version, state, logger));

      this.sock = sock;
      this.bindSocketEvents(sock, saveCreds, state);

      const qrDataUrl = await new Promise<string>((resolve, reject) => {
        let finished = false;
        const timeout = setTimeout(() => {
          if (!finished) {
            finished = true;
            reject(new Error("استغرق توليد الباركود وقتاً طويلاً. يرجى الضغط مرة أخرى."));
          }
        }, 15000);

        sock.ev.on("connection.update", async (update: Partial<ConnectionState>) => {
          if (finished) return;
          if (update.qr) {
            finished = true;
            clearTimeout(timeout);
            try {
              const url = await QRCode.toDataURL(update.qr, { margin: 2, scale: 6 });
              this.qrDataUrl = url;
              this.status = "qr_ready";
              console.log("✅ [WhatsApp Baileys] تم تجهيز باركود QR بنجاح للعرض في المتصفح!");
              resolve(url);
            } catch (e: any) {
              reject(e);
            }
          }
        });
      });

      return { success: true, qrDataUrl };
    } catch (err: any) {
      console.error("Error generating QR code:", err);
      return { success: false, error: err?.message || "فشل توليد رمز الباركود." };
    }
  }

  /**
   * Bind event handlers to socket instance (including Zero-Ban Inbound Message Auto-Reply)
   */
  private bindSocketEvents(sock: WASocket, saveCreds: any, state?: any): void {
    sock.ev.on("creds.update", async (update: any) => {
      try {
        // CRITICAL: Baileys QR pairing emits a partial update { account, me, signalIdentities, platform }
        // without mutating state.creds in place. We MUST merge `update` into `state.creds` before calling saveCreds()!
        if (state?.creds && update && typeof update === "object") {
          Object.assign(state.creds, update);
          if (update.account || update.me?.lid || state.creds.account) {
            state.creds.registered = true;
          }
        }
        await saveCreds();
      } catch (e) {
        console.warn("Failed to save WhatsApp creds:", e);
      }
    });

    // ZERO-BAN SHIELD: Listen for incoming messages from students/parents!
    // When a student/parent sends ANY message to the platform number, WhatsApp marks this thread
    // as a User-Initiated Conversation (100% immune to "starting new chats" restriction/ban).
    sock.ev.on("messages.upsert", async (m: any) => {
      try {
        if (!m || !Array.isArray(m.messages)) return;
        for (const msg of m.messages) {
          if (!msg?.key || msg.key.fromMe) continue;
          const remoteJid: string = msg.key.remoteJid || "";
          if (!remoteJid || remoteJid.endsWith("@g.us") || remoteJid === "status@broadcast") continue;

          // Extract sender phone digits
          const senderPart = remoteJid.split("@")[0]?.split(":")[0] || "";
          const formattedSender = formatWhatsAppPhone(senderPart);
          if (!formattedSender || formattedSender.length < 9) continue;

          // Record that this user has initiated a chat with us (permanently safe to reply!)
          if (!this.knownUserInitiatedPhones.has(formattedSender)) {
            this.knownUserInitiatedPhones.add(formattedSender);
            saveKnownChattedPhones(this.knownUserInitiatedPhones);
            console.log(`🛡️ [WhatsApp Zero-Ban] الطالب/ولي الأمر (+${formattedSender}) بدأ المحادثة بنفسه! الرقم آمن تماماً للرد بدون أي تقييد.`);
          }

          // Check if there is a pending OTP waiting for this user
          const pending = this.pendingOtpsByPhone.get(formattedSender);
          if (pending && !pending.delivered && pending.expiresAt > Date.now()) {
            pending.delivered = true;
            this.pendingOtpsByPhone.delete(formattedSender);

            // Wait 1.5s - 2.5s natural human read/reply delay, mark message read, and reply with the OTP!
            setTimeout(async () => {
              try {
                if (!this.sock || this.status !== "connected") return;
                try {
                  await this.sock.readMessages([msg.key]);
                } catch {}
                await new Promise((r) => setTimeout(r, 1200 + Math.floor(Math.random() * 1000)));
                await this.sock.sendMessage(remoteJid, { text: pending.messageText }, { quoted: msg });
                this.lastMessageSentAt = Date.now();
                this.recipientLastSentMap.set(formattedSender, Date.now());
                this.addLog({
                  id: `reply_${Date.now()}`,
                  timestamp: new Date().toISOString(),
                  phone: pending.phone,
                  otp: pending.otp,
                  status: "sent_reply_safe",
                  message: "تم إرسال الكود كرد تلقائي آمن 100% بعد مراسلة الطالب للمنصة (حماية مطلقة ضد التقييد والحظر).",
                });
                console.log(`✅ [WhatsApp Zero-Ban Reply] تم الرد بكود التحقق [${pending.otp}] على رسالة الطالب (+${formattedSender}) بأمان تام!`);
              } catch (replyErr: any) {
                console.warn("Failed to auto-reply with pending OTP:", replyErr?.message);
              }
            }, 1200);
          }
        }
      } catch (err) {
        console.warn("Error in messages.upsert zero-ban handler:", err);
      }
    });

    sock.ev.on("connection.update", async (update: Partial<ConnectionState>) => {
      const { connection, lastDisconnect, qr, isNewLogin } = update;

      if (isNewLogin) {
        console.log("✅ [WhatsApp Anti-Ban] تم قبول الربط من الهاتف بنجاح (isNewLogin)! جاري تثبيت الجلسة المشفرة...");
        if (state?.creds) {
          state.creds.registered = true;
          try {
            await saveCreds();
          } catch {}
        }
      }

      if (qr) {
        try {
          this.qrDataUrl = await QRCode.toDataURL(qr, { margin: 2, scale: 6 });
          if (this.status !== "pairing_code_ready") {
            this.status = "qr_ready";
          }
          console.log("📲 [WhatsApp Baileys] تم إنشاء رمز QR جديد لربط واتساب بالمنصة.");
        } catch (e) {
          console.error("Failed to generate QR data URL:", e);
        }
      }

      if (connection === "close") {
        const statusCode =
          (lastDisconnect?.error as any)?.output?.statusCode ||
          (lastDisconnect?.error as any)?.statusCode;
        // Stop reconnecting if loggedOut (401), forbidden/banned (403), method not allowed (405), or replaced (440)
        const isTerminalDisconnect =
          statusCode === DisconnectReason.loggedOut ||
          statusCode === 401 ||
          statusCode === 403 ||
          statusCode === 405 ||
          statusCode === 440;
        this.status = "disconnected";
        this.sock = null;
        this.lastError = lastDisconnect?.error?.message || "تم قطع الاتصال مؤقتاً";

        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }

        // Status 515 is WhatsApp's normal restart signal immediately after scanning QR or entering Pairing Code
        const hasPairedCreds = this.isSessionRegistered() || Boolean(state?.creds?.account);
        if (
          statusCode === DisconnectReason.restartRequired ||
          statusCode === 515 ||
          (hasPairedCreds && statusCode === DisconnectReason.connectionClosed)
        ) {
          console.log(`🔄 [WhatsApp Anti-Ban] إتمام مصافحة الربط (كود: ${statusCode || 515}) - جاري فتح الجلسة الموثقة بهدوء...`);
          this.status = "connecting";
          this.lastError = null;
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.init().catch(() => {});
          }, 1800);
          return;
        }

        // If loggedOut (401), clean up corrupted/expired session files so user can pair cleanly next time
        if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
          this.clearSessionAuth();
        }

        console.log(`⚠️ [WhatsApp Baileys] انقطع الاتصال (رمز: ${statusCode || "غير معروف"}). إعادة المحاولة الآمنة: ${!isTerminalDisconnect}`);

        // Anti-Ban: Only auto-reconnect if a verified registered session exists AND it wasn't a terminal ban/logout
        const hasSavedCreds = this.isSessionRegistered();
        if (!isTerminalDisconnect && hasSavedCreds && this.retryCount < 4) {
          this.retryCount++;
          // Slow, human-safe backoff (20s, 40s, 60s, 80s) so WhatsApp never flags reconnect storms
          const delayMs = 20000 * this.retryCount;
          console.log(`🔄 [WhatsApp Anti-Ban] إعادة اتصال هادئة وآمنة بعد ${delayMs / 1000} ثانية...`);
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.init().catch(() => {});
          }, delayMs);
        }
      } else if (connection === "open") {
        if (state?.creds) {
          state.creds.registered = true;
          try {
            await saveCreds();
          } catch {}
        }
        this.status = "connected";
        this.retryCount = 0;
        this.qrDataUrl = null;
        this.pairingCode = null;
        this.lastError = null;
        this.connectedAt = new Date().toISOString();

        const userJid = sock.user?.id || "";
        const phoneNum = userJid.split(":")[0] || userJid.split("@")[0] || this.configuredPhone;
        this.connectedNumber = phoneNum;
        // Also add our own platform number to known safe numbers for self-testing
        if (phoneNum) {
          this.knownUserInitiatedPhones.add(formatWhatsAppPhone(phoneNum));
          saveKnownChattedPhones(this.knownUserInitiatedPhones);
        }

        console.log(`\n======================================================`);
        console.log(`✅ [WhatsApp Zero-Ban] تم الاتصال بنجاح وتفعيل نظام الرد الآمن (Zero-Ban Reply Mode)!`);
        console.log(`📱 الرقم المرتبط: +${phoneNum}`);
        console.log(`🕒 وقت الاتصال: ${this.connectedAt}`);
        console.log(`======================================================\n`);
      }
    });
  }

  /**
   * Request pairing code for the platform phone (e.g. 01551955096 -> 201551955096)
   * Protected with Anti-Ban single-shot handshake & cooldown to prevent WhatsApp from flagging the SIM.
   */
  public async requestPairingCode(phoneToPair?: string): Promise<{ success: boolean; code?: string; error?: string }> {
    const targetPhone = (phoneToPair && phoneToPair.trim()) ? phoneToPair.trim() : this.configuredPhone;
    const cleanPhone = formatWhatsAppPhone(targetPhone);

    if (!cleanPhone || cleanPhone.length < 9) {
      return { success: false, error: "رقم الهاتف غير صالح لطلب كود الربط. يرجى التأكد من كتابة الرقم بشكل صحيح." };
    }

    const oldCleanPhone = formatWhatsAppPhone(this.configuredPhone);
    const isPhoneChanged = cleanPhone !== oldCleanPhone;

    if (phoneToPair && phoneToPair.trim()) {
      this.configuredPhone = phoneToPair.trim();
      savePlatformPhoneToDisk(this.configuredPhone);
    }

    try {
      // If user changed the phone number, clear old session & cooldown automatically
      if (isPhoneChanged) {
        await this.logout();
        this.lastPairingRequestedAt = 0;
      }

      // 1. If already registered and connected to the same phone
      if (this.status === "connected" && this.sock && !isPhoneChanged) {
        return {
          success: false,
          error: "الرقم مرتبط ومتصل بالفعل بمنصة مستر محمد صابر! لتغيير الرقم، اكتب الرقم الجديد واضغط حفظ وتغيير الرقم.",
        };
      }

      // 1.5 If a registered session already exists on disk
      if (this.isSessionRegistered()) {
        const savedPhone = this.getSavedRegisteredPhone();
        if (savedPhone && savedPhone !== cleanPhone) {
          await this.logout();
        } else {
          this.init().catch(() => {});
          return {
            success: false,
            error: `يوجد جلسة واتساب مسجلة بالفعل للرقم (+${savedPhone}) وجارٍ الاتصال بها. إذا أردت ربط رقم جديد يرجى الضغط على زر "فصل الرقم الحالي" أولاً.`,
          };
        }
      }

      // Anti-Ban Cooldown: If a valid pairing code was already generated in the last 90 seconds for the SAME phone AND socket is still open, return it
      const now = Date.now();
      if (
        !isPhoneChanged &&
        this.pairingCode &&
        this.sock &&
        this.status === "pairing_code_ready" &&
        now - this.lastPairingRequestedAt < 90000
      ) {
        return {
          success: true,
          code: this.pairingCode,
        };
      }

      console.log(`📞 [WhatsApp Anti-Ban] جاري تهيئة مصافحة آمنة لمرة واحدة لطلب كود الربط للرقم: +${cleanPhone}...`);

      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }

      // Clean and close any previous socket cleanly
      if (this.sock) {
        try {
          this.sock.ev.removeAllListeners("creds.update");
          this.sock.ev.removeAllListeners("connection.update");
          this.sock.ev.removeAllListeners("messages.upsert");
          this.sock.end(undefined);
        } catch {}
        this.sock = null;
      }

      await new Promise((r) => setTimeout(r, 800));
      this.clearSessionAuth();
      this.status = "connecting";
      this.isInitializing = false;
      this.initPromise = null;

      // Start fresh initialization with Anti-Ban Desktop config
      const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
      const { version } = await Promise.race([
        fetchLatestBaileysVersion(),
        new Promise<{ version: [number, number, number] }>((_, reject) =>
          setTimeout(() => reject(new Error("version timeout")), 3500)
        ),
      ]).catch(() => ({ version: [2, 3000, 1043857760] as any }));
      const logger = pino({ level: "silent" });

      const sock = safeMakeWASocket(this.createAntiBanSocketConfig(version, state, logger));

      this.sock = sock;
      this.bindSocketEvents(sock, saveCreds, state);

      // Single-Shot Handshake: Call requestPairingCode STRICTLY ONCE when the QR/Noise handshake is ready
      const rawCode = await new Promise<string>((resolve, reject) => {
        let finished = false;
        let attempted = false;
        const timeout = setTimeout(() => {
          if (!finished) {
            finished = true;
            reject(new Error("استغرق الاتصال بسيرفرات واتساب وقتاً أطول من المعتاد. يفضل استخدام مسح باركود QR بالكاميرا لأنه أسرع وأكثر أماناً."));
          }
        }, 20000);

        sock.ev.on("connection.update", async (update) => {
          if (finished || attempted) return;
          if (update.qr) {
            attempted = true;
            try {
              // Natural human pause (1.2s) after Noise/QR handshake before requesting pairing code once
              await new Promise((r) => setTimeout(r, 1200));
              if (finished) return;
              console.log(`🔐 [WhatsApp Anti-Ban] طلب كود الربط لمرة واحدة فقط لحماية الرقم +${cleanPhone}...`);
              const code = await sock.requestPairingCode(cleanPhone);
              if (!finished && code) {
                finished = true;
                clearTimeout(timeout);
                resolve(code);
              }
            } catch (e: any) {
              if (!finished) {
                finished = true;
                clearTimeout(timeout);
                reject(e);
              }
            }
          }
        });
      });

      const formattedCode = rawCode?.match(/.{1,4}/g)?.join("-") || rawCode;
      this.pairingCode = formattedCode;
      this.lastPairingRequestedAt = Date.now();
      this.status = "pairing_code_ready";

      console.log(`\n======================================================`);
      console.log(`🔐 [WhatsApp Anti-Ban] تم استلام كود الربط الآمن بنجاح!`);
      console.log(`📱 الرقم المطلوب ربطه: +${cleanPhone}`);
      console.log(`🔢 كود الربط المكون من 8 خانات: [ ${formattedCode} ]`);
      console.log(`======================================================\n`);

      return { success: true, code: formattedCode };
    } catch (err: any) {
      console.error("Error requesting pairing code:", err);
      const errMsg = String(err?.message || err);
      if (errMsg.includes("rate-overlimit") || errMsg.includes("429")) {
        this.lastError = "تنبيه حماية الرقم: يرجى الانتظار دقيقتين قبل طلب كود ربط جديد أو استخدام مسح باركود QR بالكاميرا لتجنب حظر الرقم من واتساب.";
      } else if (errMsg.includes("Connection Closed") || errMsg.includes("timed out") || errMsg.includes("reset")) {
        this.lastError = "انقطع الاتصال بسيرفرات واتساب مؤقتاً. يفضل الربط عبر مسح رمز QR بالكاميرا لأنه أكثر أماناً واستقراراً.";
      } else {
        this.lastError = err?.message || "فشل طلب كود الربط من واتساب.";
      }
      return { success: false, error: this.lastError };
    }
  }

  public setMetaConfig(config: Partial<MetaCloudConfig>): void {
    this.metaConfig = {
      token: config.token !== undefined ? config.token : this.metaConfig.token,
      phoneNumberId: config.phoneNumberId !== undefined ? config.phoneNumberId : this.metaConfig.phoneNumberId,
      wabaId: config.wabaId !== undefined ? config.wabaId : this.metaConfig.wabaId,
      templateName: config.templateName !== undefined ? config.templateName : this.metaConfig.templateName,
    };
    this.lastMetaError = null;
  }

  public clearMetaConfig(): void {
    this.metaConfig = {
      token: "",
      phoneNumberId: "",
      wabaId: "",
      templateName: "",
    };
    this.lastMetaError = null;
  }

  private lastMetaError: string | null = null;

  public getMetaConfig(): MetaCloudConfig {
    return { ...this.metaConfig };
  }

  /**
   * Send WhatsApp OTP using official Meta WhatsApp Cloud API (Graph API)
   * Reliable 24/7 cloud delivery directly from Meta servers without needing a connected phone.
   */
  public async sendViaMetaCloud(
    formattedPhone: string,
    otp: string,
    messageText: string
  ): Promise<SendOtpResult | null> {
    const token = (this.metaConfig.token || process.env.META_WHATSAPP_TOKEN || process.env.WHATSAPP_CLOUD_API_TOKEN || "").trim();
    const phoneNumberId = (this.metaConfig.phoneNumberId || process.env.META_WHATSAPP_PHONE_NUMBER_ID || process.env.WHATSAPP_PHONE_NUMBER_ID || "").trim();

    if (!token || !phoneNumberId) {
      return null;
    }

    const cleanPhone = formattedPhone.replace(/\+/g, "").trim();
    const url = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    const templateName = (this.metaConfig.templateName || process.env.META_WHATSAPP_TEMPLATE_NAME || "").trim();

    let payload: any;
    if (templateName) {
      payload = {
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: cleanPhone,
        type: "template",
        template: {
          name: templateName,
          language: { code: "ar" },
          components: [
            {
              type: "body",
              parameters: [{ type: "text", text: otp }],
            },
            {
              type: "button",
              sub_type: "url",
              index: "0",
              parameters: [{ type: "text", text: otp }],
            },
          ],
        },
      };
    } else {
      payload = {
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: cleanPhone,
        type: "text",
        text: {
          preview_url: false,
          body: messageText,
        },
      };
    }

    try {
      console.log(`📡 [Meta Cloud API] جاري الإرسال عبر خوادم Meta الرسمية للرقم (+${cleanPhone})...`);
      const resp = await axios.post(url, payload, { headers, timeout: 10000 });
      const msgId = resp.data?.messages?.[0]?.id || `meta_${Date.now()}`;
      this.lastMetaError = null;
      console.log(`✅ [Meta Cloud API] تم تسليم الرسالة بنجاح عبر بوابة Meta الرسمية! معرف الرسالة: ${msgId}`);
      return {
        success: true,
        messageId: msgId,
        phone: formattedPhone,
        deliveredDirectly: true,
      };
    } catch (err: any) {
      const errDetail = err?.response?.data?.error?.message || err?.message || "خطأ غير معروف في Meta API";
      console.error("❌ [Meta Cloud API] خطأ أثناء الإرسال عبر Meta:", errDetail);
      this.lastMetaError = errDetail;
      this.lastError = `Meta Cloud API: ${errDetail}`;
      return null;
    }
  }

  /**
   * Send WhatsApp OTP with Zero-Ban Architecture:
   * - Always queues the OTP in `pendingOtpsByPhone` so if the student/parent clicks "أرسل رسالة لاستلام الكود فوراً"
   *   and messages the platform number on WhatsApp, our `messages.upsert` handler replies within 1 second (100% immune to bans & works even while account is restricted from starting new chats!).
   * - Only sends directly if the user has ALREADY messaged the platform number previously (existing conversation) or if explicitly testing to the platform's own number.
   */
  public async sendOtp(
    studentPhone: string,
    otp: string,
    customMessage?: string,
    skipDelay?: boolean
  ): Promise<SendOtpResult> {
    const formattedPhone = formatWhatsAppPhone(studentPhone);
    const messageText = customMessage || generateOtpMessage(otp);
    const timestamp = new Date().toISOString();
    const nowMs = Date.now();
    const platformFormatted = formatWhatsAppPhone(this.connectedNumber || this.configuredPhone);
    const whatsappTriggerLink = buildWhatsAppTriggerLink(this.connectedNumber || this.configuredPhone);

    // Always register the OTP in pendingOtpsByPhone so as soon as the student sends ANY message to our WhatsApp number,
    // we reply immediately with the OTP (100% Zero-Ban & works even when WhatsApp restricts starting new chats!)
    this.pendingOtpsByPhone.set(formattedPhone, {
      phone: studentPhone,
      formattedPhone,
      otp,
      messageText,
      createdAt: nowMs,
      expiresAt: nowMs + 10 * 60 * 1000,
      delivered: false,
    });

    console.log(`\n======================================================`);
    console.log(`📱 [WhatsApp OTP Engine] تجهيز رمز التحقق OTP:`);
    console.log(`📞 هاتف المستخدم: ${studentPhone} (الدولي: +${formattedPhone})`);
    console.log(`🔑 الرمز: [ ${otp} ]`);
    console.log(`======================================================\n`);

    // Trigger Botpress Cloud Webhook asynchronously in background (non-blocking) if configured
    if (BOTPRESS_CONFIG.API_KEY && BOTPRESS_CONFIG.WEBHOOK_URL) {
      sendOtpToWhatsApp({
        studentPhone: formattedPhone,
        otpCode: otp,
        customMessage: messageText,
        skipDelay: true,
      }).catch((bpErr: any) => {
        console.warn("⚠️ [Botpress WhatsApp Warning]:", bpErr?.message || bpErr);
      });
    }

    // Priority 1: Official Meta WhatsApp Cloud API (If configured, zero ban risk on personal SIM)
    try {
      const metaResult = await this.sendViaMetaCloud(formattedPhone, otp, messageText);
      if (metaResult && metaResult.success) {
        this.pendingOtpsByPhone.delete(formattedPhone);
        this.addLog({
          id: metaResult.messageId || `meta_${Date.now()}`,
          timestamp,
          phone: studentPhone,
          otp,
          status: "sent_meta_cloud",
          message: "تم الإرسال فورياً عبر بوابة Meta WhatsApp Cloud API الرسمية السحابية.",
        });
        return {
          ...metaResult,
          whatsappTriggerLink,
          platformWhatsAppPhone: this.configuredPhone,
        };
      }
    } catch (metaErr: any) {
      console.warn("Meta Cloud API failed:", metaErr?.message);
    }

    // Priority 2: Connected Baileys instance with ZERO-BAN Reply Protection
    if (this.sock && this.status === "connected") {
      const isExistingChatOrSelf =
        Boolean(skipDelay) ||
        this.knownUserInitiatedPhones.has(formattedPhone) ||
        formattedPhone === platformFormatted;

      // CRITICAL ZERO-BAN RULE:
      // WhatsApp restricts/bans numbers that initiate "new chats" with unsaved numbers ("لن تتمكن من بدء دردشات جديدة").
      // If this user has NOT messaged us before, we DO NOT initiate a cold chat!
      // Instead, we instruct the frontend to let the user click the 1-tap WhatsApp link to message us first,
      // and our `messages.upsert` listener replies with the OTP in 1 second!
      if (!isExistingChatOrSelf) {
        console.log(
          `🛡️ [WhatsApp Zero-Ban] الرقم (+${formattedPhone}) لم يراسل المنصة من قبل. تم تفعيل وضع "الرد الآمن" (منع بدء دردشة جديدة لحماية رقم المنصة من الحظر والتقييد). سيصل الكود فور إرسال الطالب لرسالة البدء.`
        );
        this.addLog({
          id: `awaiting_reply_${nowMs}`,
          timestamp,
          phone: studentPhone,
          otp,
          status: "awaiting_user_message",
          message: `جاهز للرد الآمن فور مراسلة الطالب لرقم المنصة (+${this.configuredPhone}) لمنع الحظر 100%. الكود: [${otp}]`,
        });
        return {
          success: true,
          messageId: `awaiting_user_init_${nowMs}`,
          phone: formattedPhone,
          deliveredDirectly: false,
          requiresUserInitiatedChat: true,
          whatsappTriggerLink,
          platformWhatsAppPhone: this.configuredPhone,
        };
      }

      try {
        // Anti-Ban Guard 1: Per-recipient cooldown
        const lastToRecipient = this.recipientLastSentMap.get(formattedPhone) || 0;
        if (lastToRecipient > 0 && nowMs - lastToRecipient < this.minRecipientCooldownMs) {
          return {
            success: true,
            messageId: `antiban_cooldown_${nowMs}`,
            phone: formattedPhone,
            deliveredDirectly: true,
            whatsappTriggerLink,
            platformWhatsAppPhone: this.configuredPhone,
          };
        }

        const targetJid = `${formattedPhone}@s.whatsapp.net`;

        // Queue messages sequentially with natural human spacing (5s - 9s) WITHOUT calling sock.onWhatsApp or presenceSubscribe
        const sent = await new Promise<any>((resolve, reject) => {
          this.sendQueue = this.sendQueue
            .catch(() => {})
            .then(async () => {
              try {
                if (!this.sock || this.status !== "connected") {
                  throw new Error("انقطع اتصال واتساب قبل الإرسال.");
                }

                const elapsed = Date.now() - this.lastMessageSentAt;
                const minGapMs = 5000 + Math.floor(Math.random() * 4000);
                if (this.lastMessageSentAt > 0 && elapsed < minGapMs) {
                  await new Promise((r) => setTimeout(r, minGapMs - elapsed));
                }

                const resMsg = await this.sock.sendMessage(targetJid, { text: messageText });
                const sentTime = Date.now();
                this.lastMessageSentAt = sentTime;
                this.recipientLastSentMap.set(formattedPhone, sentTime);
                this.hourlySentTimestamps.push(sentTime);
                resolve(resMsg);
              } catch (err) {
                reject(err);
              }
            });
        });

        this.pendingOtpsByPhone.delete(formattedPhone);
        const messageId = sent?.key?.id || `baileys_${Date.now()}`;
        console.log(`✅ [WhatsApp Zero-Ban] تم إرسال الكود في المحادثة المفتوحة مسبقاً بأمان! (معرف: ${messageId})`);

        this.addLog({
          id: messageId,
          timestamp,
          phone: studentPhone,
          otp,
          status: "sent_direct",
          message: "تم الإرسال الآمن في محادثة مفتوحة مسبقاً مع الطالب.",
        });

        return {
          success: true,
          messageId,
          phone: formattedPhone,
          deliveredDirectly: true,
          whatsappTriggerLink,
          platformWhatsAppPhone: this.configuredPhone,
        };
      } catch (sendErr: any) {
        console.error("❌ تعذر الإرسال المباشر، سيتم التسليم عبر الرد التلقائي فور مراسلة الطالب:", sendErr?.message || sendErr);
        this.lastError = sendErr?.message;
        return {
          success: true,
          messageId: `fallback_reply_${nowMs}`,
          phone: formattedPhone,
          deliveredDirectly: false,
          requiresUserInitiatedChat: true,
          whatsappTriggerLink,
          platformWhatsAppPhone: this.configuredPhone,
        };
      }
    }

    // 2. Fallback to external gateway URL if configured
    const baileysGatewayUrl =
      process.env.WHATSAPP_BAILEYS_URL ||
      process.env.WHATSAPP_API_URL ||
      process.env.BAILEYS_GATEWAY_URL;

    if (baileysGatewayUrl) {
      try {
        const apiKey = process.env.WHATSAPP_API_KEY || process.env.BAILEYS_API_KEY;
        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;

        const response = await axios.post(
          baileysGatewayUrl,
          {
            phone: formattedPhone,
            jid: `${formattedPhone}@s.whatsapp.net`,
            otp,
            message: messageText,
            senderPhone: this.configuredPhone,
            app: "QalbElElm",
            timestamp,
          },
          { headers, timeout: 8000 }
        );

        const messageId = response.data?.messageId || response.data?.id || `gateway_${Date.now()}`;
        this.addLog({
          id: messageId,
          timestamp,
          phone: studentPhone,
          otp,
          status: "sent_gateway",
          message: "تم الإرسال عبر بوابة واتساب السحابية.",
        });

        return {
          success: true,
          messageId,
          phone: formattedPhone,
          deliveredDirectly: true,
          whatsappTriggerLink,
          platformWhatsAppPhone: this.configuredPhone,
        };
      } catch (gwErr: any) {
        console.warn("Gateway forward failed:", gwErr?.message);
      }
    }

    // 3. Fallback: Log code for simulation & offline notice when phone is not yet paired
    const fallbackId = `offline_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    this.addLog({
      id: fallbackId,
      timestamp,
      phone: studentPhone,
      otp,
      status: "queued_offline",
      message: `في انتظار مراسلة الطالب للرقم (+${this.configuredPhone}) للرد التلقائي بالكود [${otp}].`,
    });

    return {
      success: true,
      messageId: fallbackId,
      phone: formattedPhone,
      deliveredDirectly: false,
      requiresUserInitiatedChat: true,
      whatsappTriggerLink,
      platformWhatsAppPhone: this.configuredPhone,
      error: "يرجى إرسال رسالة بدء المحادثة إلى رقم واتساب المنصة لاستلام الكود فوراً.",
    };
  }

  private lastAutoInitAt = 0;

  public getStatus(): WhatsAppConnectionStatus {
    const sessionExists = this.isSessionRegistered();
    const savedPhone = this.getSavedRegisteredPhone();

    const hasMetaCredentials = Boolean(
      (this.metaConfig.token || process.env.META_WHATSAPP_TOKEN || process.env.WHATSAPP_CLOUD_API_TOKEN) &&
      (this.metaConfig.phoneNumberId || process.env.META_WHATSAPP_PHONE_NUMBER_ID || process.env.WHATSAPP_PHONE_NUMBER_ID)
    );
    const metaCloudApiConfigured = hasMetaCredentials && !this.lastMetaError;

    // Live connection check for Baileys phone socket strictly
    const isBaileysLive = this.status === "connected" && Boolean(this.sock);

    // If a verified session exists on disk, no socket is active, and no reconnect timer is already scheduled,
    // automatically restore the connection (with a 25-second cooldown guard to prevent reconnect storms).
    const now = Date.now();
    if (
      sessionExists &&
      !isBaileysLive &&
      !this.sock &&
      !this.isInitializing &&
      !this.reconnectTimer &&
      now - this.lastAutoInitAt > 25000
    ) {
      this.lastAutoInitAt = now;
      this.init().catch(() => {});
    }

    const botpressConfigured = Boolean(BOTPRESS_CONFIG.API_KEY && BOTPRESS_CONFIG.WEBHOOK_URL);

    let activeProvider: "botpress_cloud" | "meta_cloud_api" | "baileys_socket" | "gateway" | "offline" = "offline";
    if (isBaileysLive) {
      activeProvider = "baileys_socket";
    } else if (metaCloudApiConfigured) {
      activeProvider = "meta_cloud_api";
    } else if (process.env.WHATSAPP_BAILEYS_URL || process.env.WHATSAPP_API_URL) {
      activeProvider = "gateway";
    }

    const effectiveNumber = isBaileysLive
      ? (this.connectedNumber || savedPhone || this.configuredPhone)
      : sessionExists
      ? (savedPhone || this.configuredPhone)
      : null;

    return {
      configuredPhone: this.configuredPhone,
      formattedPhone: formatWhatsAppPhone(this.configuredPhone),
      status: this.status,
      isConnected: isBaileysLive || metaCloudApiConfigured,
      isBaileysConnected: isBaileysLive,
      connectedNumber: effectiveNumber,
      connectedAt: isBaileysLive ? this.connectedAt : null,
      qrDataUrl: this.qrDataUrl,
      pairingCode: this.pairingCode,
      lastError: this.lastError,
      lastMetaError: this.lastMetaError,
      sessionExists,
      recentLogs: this.recentLogs.slice(-20),
      metaCloudApiConfigured,
      metaPhoneNumberId: this.metaConfig.phoneNumberId || process.env.META_WHATSAPP_PHONE_NUMBER_ID || null,
      botpressConfigured,
      botpressBotId: BOTPRESS_CONFIG.BOT_ID,
      botpressWebhookUrl: BOTPRESS_CONFIG.WEBHOOK_URL,
      activeProvider,
      zeroBanReplyMode: true,
      knownChattedCount: this.knownUserInitiatedPhones.size,
    };
  }

  public async changePhoneNumber(newPhone: string): Promise<{ success: boolean; configuredPhone: string; error?: string }> {
    const cleaned = formatWhatsAppPhone(newPhone);
    if (!cleaned || cleaned.length < 9) {
      return {
        success: false,
        configuredPhone: this.configuredPhone,
        error: "يرجى إدخال رقم هاتف صحيح (مثال: 01551955096 أو 01040672314).",
      };
    }

    const oldCleaned = formatWhatsAppPhone(this.configuredPhone);
    const savedPhone = this.getSavedRegisteredPhone();
    this.configuredPhone = newPhone.trim();
    savePlatformPhoneToDisk(this.configuredPhone);

    // Only logout and wipe session if the phone number is actually different from the currently registered/configured phone!
    // This prevents accidental clicks on "Save Phone" from logging out an active session for the same number.
    const isDifferentFromOld = cleaned !== oldCleaned;
    const isDifferentFromSaved = Boolean(savedPhone && savedPhone !== cleaned);
    if (isDifferentFromOld || isDifferentFromSaved) {
      await this.logout();
      this.lastPairingRequestedAt = 0;
    }

    return {
      success: true,
      configuredPhone: this.configuredPhone,
    };
  }

  public async restart(newPhone?: string): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    const oldClean = formatWhatsAppPhone(this.configuredPhone);
    if (newPhone && newPhone.trim()) {
      this.configuredPhone = newPhone.trim();
      savePlatformPhoneToDisk(this.configuredPhone);
    }
    const newClean = formatWhatsAppPhone(this.configuredPhone);

    if (this.sock) {
      try {
        this.sock.ev.removeAllListeners("creds.update");
        this.sock.ev.removeAllListeners("connection.update");
        this.sock.end(undefined);
      } catch {}
      this.sock = null;
    }

    // Only wipe auth credentials if the phone number changed; otherwise preserve the saved session and reconnect!
    if (newClean !== oldClean) {
      this.clearSessionAuth();
      this.connectedNumber = null;
      this.status = "disconnected";
    } else if (this.isSessionRegistered()) {
      this.status = "connecting";
      this.isInitializing = false;
      this.initPromise = null;
      await this.init();
      return;
    } else {
      this.clearSessionAuth();
      this.status = "disconnected";
    }

    this.qrDataUrl = null;
    this.pairingCode = null;
    this.lastPairingRequestedAt = 0;
    this.isInitializing = false;
  }

  public async logout(): Promise<void> {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.sock) {
      try {
        await this.sock.logout();
      } catch {}
      try {
        this.sock.end(undefined);
      } catch {}
      this.sock = null;
    }
    this.clearSessionAuth();
    this.status = "disconnected";
    this.connectedNumber = null;
    this.connectedAt = null;
    this.qrDataUrl = null;
    this.pairingCode = null;
  }

  private clearSessionAuth(): void {
    if (fs.existsSync(AUTH_DIR)) {
      try {
        const files = fs.readdirSync(AUTH_DIR);
        for (const file of files) {
          fs.unlinkSync(path.join(AUTH_DIR, file));
        }
      } catch (e) {
        console.warn("Could not remove old session files:", e);
      }
    }
  }

  private addLog(entry: WhatsAppLogEntry): void {
    this.recentLogs.unshift(entry);
    if (this.recentLogs.length > 50) {
      this.recentLogs.pop();
    }
  }
}

export const whatsappManager = new WhatsAppBaileysManager();

// Only auto-start Baileys in background if a previously verified session exists on disk
// (Prevents unauthenticated background sockets from connecting on every server restart and flagging the IP/number)
setTimeout(() => {
  if (whatsappManager.isSessionRegistered()) {
    whatsappManager.init().catch((e) => {
      console.warn("WhatsApp background auto-init notice:", e?.message || e);
    });
  }
}, 2500);

export async function sendOtpViaBaileys(
  studentPhone: string,
  otp: string,
  customMessage?: string,
  skipDelay?: boolean
): Promise<SendOtpResult> {
  return whatsappManager.sendOtp(studentPhone, otp, customMessage, skipDelay);
}

export function generateParentOtpMessage(otp: string, studentNames: string): string {
  return (
    `أهلاً بحضرتك في منصة مستر محمد صابر التعليمية 🎓\n` +
    `رسالة خاصة لولي أمر الطالب: ${studentNames || "الطالب"}\n\n` +
    `رمز التأكيد لتوثيق بيانات الطالب وربط المتابعة الأبوية هو:\n` +
    `*${otp}*\n\n` +
    `الرمز صالح لمدة 5 دقائق، مع خالص تمنياتنا بالتوفيق والنجاح.`
  );
}

export async function sendParentOtpViaBaileys(
  parentPhone: string,
  otp: string,
  studentNames: string = 'الطالب',
  skipDelay?: boolean
): Promise<SendOtpResult> {
  const customMessage = generateParentOtpMessage(otp, studentNames);
  return whatsappManager.sendOtp(parentPhone, otp, customMessage, skipDelay);
}

export default sendOtpViaBaileys;
