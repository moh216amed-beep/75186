import { Course } from '../types';

/**
 * Platform courses are strictly fetched from Firebase Firestore and backend API.
 * No hardcoded or dummy courses are injected.
 */
export const DEFAULT_COURSES: Course[] = [];
